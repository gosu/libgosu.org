include Gosu

class Prey < Entity
  attr_accessor :eaten
 
  def initialize(game)
    super(game)
    @accel = P_ACCEL
    @eaten = false
  end
 
  def update(hunters)
    # Find the closest hunter and accelerate away
    closest = find_closest(hunters)
    # take the angle from the hunter to the prey and run along that path
  accelerate(angle(closest.x, closest.y, @x, @y) + 90)
    move
    !@eaten  # return to verify existence
  end
 
  def draw
    @game.draw_square(@x, @y, 3, 0xff00ff00)
  end
end

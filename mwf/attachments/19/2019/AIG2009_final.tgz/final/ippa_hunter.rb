include Gosu

#
# normal hunter eats all preys in ~40-50
# 
class Hunter < Entity
  
  attr_reader :frags, :color
  
  def initialize(game, color)
    super(game)    # Entity will define @game
    @accel = H_ACCEL
    @color = color
    @frags = 0
    
    @ticks = 0
    @ms_start = milliseconds()
  end
    
  def update(preys)
    # Find the closest prey and accelerate towards it
    closest = find_closest(preys)
    # if closest is too close, eat it
    if distance(closest.x, closest.y, @x, @y) < 5
      closest.eaten = true
      @frags += 1
    end
    
    distance_to_closest_prey = distance(closest.x, closest.y, @x, @y)
    #
    # The strategy here is to gang up in the middle for a while
    # and make the prey summon in the corners, Then go after them.
    #
    if time_in_seconds < 5
      accelerate(angle(@x, @y, WIDTH/2, HEIGHT/2))
    else
      #
      # The idea for the hunters to slow down nearing the corners.. didn't work out as good as I expected.
      #
      
      #distance_from_center = distance(HEIGHT/2, WIDTH/2, 0, 0)
      #distance_to_closest_corner = distance_from_center
      
      #[[0,0], [0, WIDTH], [HEIGHT, WIDTH], [HEIGHT, 0]].each do |x, y|
      #  dis = distance(@x, @y, x, y)
      #  distance_to_closest_corner = dis if dis < distance_to_closest_corner
      #end
            
      #corner_ratio = distance_to_closest_corner / distance_from_center
      #prey_ratio = distance_to_closest_prey / 30
      # accelerate2(angle(@x, @y, closest.x, closest.y), corner_ratio * prey_ratio)
      
      accelerate(angle(@x, @y, closest.x, closest.y))
    end

    move
    @ticks += 1
  end
  
  
  # returns time in seconds
  def time_in_seconds
    (milliseconds() - @ms_start) / 1000
  end
  
  #
  # Nothing cheating about this, only a way to accelerate Slower then the default.
  #
  def accelerate2(dir, ratio = 1.0)
    ratio = 1 if ratio > 1 # Never accept speed-cheating
    
    @vx += offset_x(dir, @accel*ratio)
    @vy += offset_y(dir, @accel*ratio)
  end
  
  def draw
    @game.draw_square(@x, @y, H_RADIUS, @color)
  end  
end


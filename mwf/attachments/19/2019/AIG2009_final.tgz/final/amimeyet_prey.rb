include Gosu

# Prey class by AmIMeYet @ amimeyet.hostcell.net (temp site?)
# For the AIG 2009 competition by phelps.db (you?)
#
# Score: ~70
# Awesomeness: (1/0)

class Prey < Entity
  attr_accessor :eaten
  
  def initialize(game)
    super(game)
    @accel = P_ACCEL
    @eaten = false
    @dir = rand(360)
    @count = 0
    @count_max = 120
  end
  
  def update(hunters)
    if @y < 100
      diff = angle_diff(0,@dir)
      diff = 0.1 if diff.abs < 0.1 #Thanks, phelps.db! :D
      sign = diff <=> 1
      if sign > 0
        @dir += 100*(diff**-1)
      elsif sign < 0
        @dir -= 100*(diff**-1)
      end
    elsif @x < 100
      diff =  angle_diff(270,@dir)
      diff = 0.1 if diff.abs < 0.1
      sign = diff <=> 1
      if sign > 0
        @dir += 100*(diff**-1)
      elsif sign < 0
        @dir -= 100*(diff**-1)
      end
    elsif @x > WIDTH-100
      diff = angle_diff(90,@dir)
      diff = 0.1 if diff.abs < 0.1
      sign = diff <=> 1
      if sign > 0
        @dir += 100*(diff**-1)
      elsif sign < 0
        @dir -= 100*(diff**-1)
      end
    elsif @y > HEIGHT-100
      diff =  angle_diff(180,@dir)
      diff = 0.1 if diff.abs < 0.1
      sign = diff <=> 1
      if sign > 0
        @dir += 100*(diff**-1)
      elsif sign < 0
        @dir -= 100*(diff**-1)
      end
    end
    
    @count += 1
    if @count >= @count_max
      left_bound = @dir.round-220
      right_bound = @dir.round-180
      possible_dirs = [*left_bound..right_bound]
      chosendir = possible_dirs[rand(possible_dirs.length-1)]
      @dir = chosendir
      @count = 0
    end
    
    accelerate(@dir)

    move
    !@eaten  # return to verify existence.. aaaww
  end
  
  def draw
    @game.draw_square(@x, @y, 3, 0xff00ff00)
  end
end

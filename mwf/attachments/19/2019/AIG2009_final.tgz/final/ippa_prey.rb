include Gosu

class Array
  def rand 
    self[Kernel.rand(self.length)] 
  end   
end

class Prey < Entity
  attr_accessor :eaten
  
  def initialize(game)
    super(game)
    @accel = P_ACCEL
    @eaten = false
  
    @type = rand(4)

    @ticks = 0
    @ticks2 = 0
    
    @ticks2_max = rand(50) + 40
    
    if @x < 100 || @y < 100
      @ticks2 = @ticks2_max 
    end
    
    #@first = rand(180)        if @x < 100
    #@first = 180 + rand(180)  if @x > 400
    #@first = 180 + rand(180)  if @y < 100
  end
  
  def update(hunters)
  
    closest = find_closest(hunters)
        
    if @type == 0
      #accelerate(angle(closest.x, closest.y, @x, @y))
      a = (@ticks2 < @ticks2_max) ? 135 : 215 #rightup / leftdown
      accelerate(a)      
    
    elsif @type == 1
      a = (@ticks2 < @ticks2_max) ? 90 : 270  # right/left
      accelerate(a)
      
    elsif @type == 2
      a = (@ticks2 < @ticks2_max) ? 0 : 180   # up/down
      accelerate(a)
      
    elsif @type == 3
      a = (@ticks2 < @ticks2_max) ? 45 : 225
      accelerate(a)
    end
      
    
    

    move
    @ticks += 1
    @ticks2 += 1
    @ticks2 = 0 if @ticks2 > @ticks2_max*2
    !@eaten  # return to verify existence
  end
  
  def draw
    @game.draw_square(@x, @y, 3, 0xff00ff00)
  end
end

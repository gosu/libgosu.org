class HUD < Chingu::BasicGameObject
	# include Chingu
	def initialize(options={})
		super
		@player = options[:player] || parent.player
	end
	
	def draw
		Text.new(@player.hp, :x => 20, :y => 36).draw
		$window.fill_rect(Rect.new(20,20,102,12), Color.new(255,255,255))
		$window.fill_rect(Rect.new(21,21,100*@player.hp/@player.maxhp,10), Color.new(240,80,80))
	end
end
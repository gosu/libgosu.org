# ------------------------------------------------------
# Le Player
# Animated
# ------------------------------------------------------
class Player < Chingu::GameObject
	attr_accessor :direction, :inverse, :invincible, :hp, :maxhp, :status, :action
	trait :bounding_box, :scale => [0.4, 0.8], :debug => false
	traits :timer, :collision_detection, :timer, :velocity
		
	def initialize(option={})
		super
		self.input = {
			:holding_left => :move_left,
			:holding_right => :move_right,
			[:released_left, :released_right] => :stand,
			:z => :jump,
			:x => :fire
		}
		@animations = Chingu::Animation.new( :file => "mark.png", :size => [32,32])
		@animations.frame_names = {
			:stand => 0..0,
			:walk => 1..4,
			:shoot => 5..7,
			:crouch => 8..8,
			:c_shoot => 9..11,
			:jump => 12..12,
			:hurt => 13..13,
			:die => 14..14
		}

		@inverse = false
		@animations[:shoot].delay = 100 # ensure attack
		@animations[:c_shoot].delay = 100 # ensure attack
		@image = @animations[:stand].first
		@speed = 2
		@hp = @maxhp = 5
		# @h = 0
		# @hurt = false
		# @jumping = false
		# @crouching = false
		@status = :stand
		@action = :stand
		@invincible = false
		@subweapon = false
		
		self.zorder = 300
		self.acceleration_y = 0.5
		self.max_velocity =  8
		self.rotation_center = :bottom_center
		
		@last_x, @last_y = @x, @y
		@y_flag = @y
		# update
		cache_bounding_box
	end
	
	def stand
		unless @status == :jump
			@image = @animations[:stand].first
			@status = :stand
		end
	end
	
	def move_left
		return if (@action == :attack && @status == :stand) || @status == :hurt || @status == :crouch
		move(-@speed, 0) # @x -= 1 
	end
	
	def move_right
		return if (@action == :attack && @status == :stand) || @status == :hurt || @status == :crouch
		move(@speed, 0) # @x += 1
	end
	
	def jump
		return if self.velocity_y > 7
		return if @status != :stand
		@status = :jump
		self.velocity_y = -8
		@y_flag = @y if @velocity_y == 7
		# @image = @animations[:jump].first
	end
	
	def land
		if @y - @y_flag > 72
			Sound["step.wav"].play
			between(1,500) { 
				@status = :crouch
				@image = @animations[:crouch].first
			}.then { @status = :stand; @image = @animations[:stand].first}
			@y_flag = @y
		else
			if @status == :jump
				@image = @animations[:stand].first 
				@status = :stand
			end
		end
	end
	
	def move(x,y)
		# @image = @animations[:walk].next
		@image = @animations[:jump].first  if @status == :jump && @action != :attack
		@image = @animations[:walk].next  if @animations && x != 0 && @status != :jump # && !holding_any?(:x)
		
		unless @action == :attack
			self.factor_x = self.factor_x.abs   if x > 0
			self.factor_x = -self.factor_x.abs  if x < 0
		end
		
		self.x += x
		self.x = previous_x   if self.outside_window? # || game_state.game_object_map.from_game_object(self)
		
		# self.x = previous_x if x <= self.parent.viewport.x + self.parent.viewport.x/10 + self.width*1/4 or
			# x >= self.parent.viewport.x + $window.width - self.parent.viewport.x/10 + self.width*1/4
			
		self.each_collision(Block, Brick, Gravel) do |me, stone_wall|
      self.x = previous_x 
      break
    end
		self.y += y
		
		# idle_status
		# check_last_direction
	end
	
	def knockback
		@sword.destroy if @sword != nil
		Sound["grunt.wav"].play(0.4)
		# Sound["hit.wav"].play(0.4)
		# self.velocity_x = -@speed/2 if !@inverse
		self.velocity_x = self.factor_x*@speed/2
		self.velocity_y = -5
		@hp -= 1
		@status = :hurt
		if @hp <= 0
			between(1, 500) {
				@invincible = true
				@image = @animations[:hurt].first }.then {die}
		else
			between(1, 500) {
				@invincible = true
				@image = @animations[:hurt].first }.then {recover}
			after(2000){@invincible = false}
		end
	end
	
	def recover
		@image = @animations[:stand].first
		@status = :stand
		self.velocity_x = 0
	end
	
	def die
		@image = @animations[:die].first
		@status = :die
		self.velocity_x = 0
	end
	
	def inverse
		return @inverse = true
	end
	
	# def deep_falling
		# Sound["step.wav"].play
		# between(1,500) { 
			# @status = :crouch
			# @image = @animations[:crouch].first
			# }.then { @jumping = false; @status = :stand; @image = @animations[:stand].first}
	# end
	
	# def idle_status
		# @image = @animations[:stand].first unless moved? or @attack
		# @image = @animations[:jump].first if @jumping and !@attack
		# @image = @animations[:die].first if hp <= 0
	# end
	
	def check_last_direction
		if @x == @last_x && @y == @last_y or @subweapon
			@direction = [self.factor_x*(2), 0]
		else
			@direction = [@x - @last_x, @y - @last_y]
		end
		@last_x, @last_y = @x, @y
	end
	
	def fire
		unless @status == :hurt
			if holding?(:up)
				unless Knife.size >= 1
					# @attack = true
					@action = :attack
					@subweapon = true					
					@image = @animations[:shoot].first
					after(90) {@image = @animations[:shoot].next}
					after(150) { 
						@image = @animations[:shoot].next 
						factor = (self.factor_x^0)
						Sound["swing.wav"].play
						h = 0; h = 9 if @status == :jump
						Knife.create(:x => self.x+(15*factor), :y => (self.y-self.height/2) - 3, :velocity => @direction, :factor => factor) }
					after(300) { @image = @animations[:stand].first; @action = :stand }
				end
			else
				unless Sword.size >= 1
					# @attack = true
					@action = :attack
					# @animation.reset
					
					@image = @animations[:shoot].first
					# @animation = @animations[:c_shoot] if @crouching
					# @animation.reset
					Sound["swing.wav"].play
					factor = (self.factor_x^0)*(-1) # @inverse? 1 : -1
					@sword = Sword.create(:x => @x+(5*factor), :y => (@y-14), :velocity => @direction, :factor_x => -factor, :angle => 90*factor)
					# h = 1; h = 6 if @crouching
					# h = 0; h = 9 if @status == :jump
					between(1, 90) {@sword.x = @x+(5*factor); @sword.y = (@y-14); @sword.angle = 90*factor; @sword.velocity = @direction}. then {@image = @animations[:shoot].next}
					between(90,150) {
						h = 0; h = 9 if @status == :jump
						@sword.x = @x-(2*factor)
						@sword.y = (@y-16)+(h-2)
						@sword.angle = 45*factor
						@sword.velocity = [0,0]}.then {@image = @animations[:shoot].last}
					between(150, 300) {
						h = 0; h = 9 if @status == :jump
						@sword.x = @x-(9*factor)+((-1)*factor)
						@sword.y = (@y-16)+(h-1)
						@sword.angle = 0*factor
						@sword.collidable = true
					}.then {@sword.die; @image = @animations[:stand].first; @action = :stand}
				end
			end
		end
	end
	
	def update		
	  self.each_collision(Block, Brick, Gravel) do |me, stone_wall|
      if self.velocity_y < 0  # Hitting the ceiling
        me.y = stone_wall.bb.bottom + me.image.height * self.factor_y
        self.velocity_y = 0
      else  # Land on ground
				land
				self.velocity_y = 7
        me.y = stone_wall.bb.top - 1
      end
    end
		
		# idle_status
		check_last_direction
		@y_flag = @y if @velocity_y == 7
	end
end
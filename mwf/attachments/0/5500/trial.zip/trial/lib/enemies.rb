# ------------------------------------------------------
# Le Ball
# Don't stop me now!
# ------------------------------------------------------
class Ball < GameObject
  trait :bounding_circle, :debug => false
	traits :collision_detection, :effect, :velocity, :timer
	attr_accessor :rotation, :invincible
	
	def setup
		@image = Image["ball.png"]
		@speed = 2
		# self.velocity_x = @speed
		# self.factor = 2 # double ze sprite
		@rotation = 5
		@invincible = false
		@hp = 1
		# cache_bounding_circle
	end
	
	# def update
		# self.angle += @rotation if moved?
	# end
	
	def die
		Sound["hit.wav"].play
		@hp -= 1
		during(200){ self.collidable = false; @factor_x += 0.1; @factor_y += 0.1; @color.alpha -= 10 }.then {self.destroy} if @hp == 0
		@invincible = true
		dir = self.velocity_x
		self.velocity_x *= 0
		after(300) { @invincible = false; self.velocity_x = dir; }
	end
end
# ------------------------------------------------------
# Le Scene
# self titled
# ------------------------------------------------------
class Scene < GameState
	traits :viewport, :timer, :debug => true
	
	def initialize(options={})
		super
		
		self.input = { :escape => :exit, :e => :edit, :r => :restart }
		# self.input = { :escape => :exit, :r => :restart }
		self.viewport.game_area = [0,0,600,360]
		self.viewport.lag = 0.95
		game_objects.select { |game_object| !game_object.is_a? Player }.each { |game_object| p game_object; game_object.destroy }
		load_game_objects
		@game_object_map = GameObjectMap.new(:game_objects => Brick.all + Gravel.all, :grid => @grid)
		@player = Player.create(:x => 64, :y => 268)
		@hud = HUD.new(:player => @player, :x => 20, @y => 20)
		# @ball = Ball.create(:x => -100, :y => 50)
		
		# @song = Gosu::Song.new("media/RipeSeeds.ogg")
		# @song.play(true)
		
	end
	
	def draw
		fill(Color.new(80,80,240))
		@hud.draw
		# @map.draw
		super
	end
	
	def edit
    push_game_state(GameStates::Edit.new(:grid => [24,24], :classes => [Brick, Gravel]))
  end
	
	def restart
		switch_game_state(Scene)
	end
	
	def update
		super
		# @hud.update
		# @player.each_collision(Ball) do |me, ball|
			# me.knockback unless me.invincible
		# end
		# Ball.each_collision(Sword) do |ball, sword|
			# unless ball.invincible
				# ball.die 
			# end
		# end
		# Ball.each_collision(Knife) do |ball, knife|
			# unless ball.invincible
				# ball.die
				# knife.die
			# end
		# end
		# Knife.each_collision(Block, Brick, Gravel) do |knife, wall|
		Knife.each_collision(Block, Brick, Gravel) do |knife, wall|
			knife.hit_the_wall
		end
		# if @player.x > 300 
		# end
		self.viewport.center_around(@player)
		# Knife.destroy_if {|knife| knife.outside_window? or self.viewport.outside_game_area?(knife)}
		Knife.destroy_if {|knife| 
			knife.x > self.viewport.x + $window.width + $window.width/10 or 
			# knife.x < self.viewport.x - $window.width or 
			knife.x < self.viewport.x - + $window.width/10 or 
			self.viewport.outside_game_area?(knife)
			}
		$window.caption = "Le Trial, FPS: #{$window.fps}, #{@player.action}, #{@player.status}"
		# $window.caption = "Le Trial, FPS: #{$window.fps}, Coord: #{@player.x}, #{@player.y}, Grav: #{@player.velocity_y}"
	end
end
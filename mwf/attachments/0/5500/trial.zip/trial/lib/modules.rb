# module Properties
	# module Maps
		# Maps = [Block, Brick, Gravel]
		# Maps.each do |ter|
			# Terrain += ter
		# end
	# end
# end
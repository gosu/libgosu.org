# ------------------------------------------------------
# Le Weapon
# When you need self-defense
# ------------------------------------------------------
class Sword < GameObject
	trait :bounding_box, :scale => [1, 0.5],:debug => false
	traits :collision_detection, :timer, :velocity
	
	def setup
		@image = Image["sword.bmp"]
		self.rotation_center = :center_left
		@zorder = 300
		@velocity_x *= 1
		@velocity_y *= -1 if self.velocity_y > 0
		@velocity_y *= 1
		@collidable = true
		cache_bounding_box
	end
	
	def die
		self.destroy!
	end
end

# ------------------------------------------------------
# Le Projectile
# When you might need something to throw...
# ------------------------------------------------------
class Knife < GameObject
	trait :bounding_box, :scale => [1, 1],:debug => false
	traits :collision_detection, :timer, :velocity
	
	def setup
		@image = Image["knife.png"]
		@zorder = 300
		@velocity_x *= 6
		@velocity_y *= 0
		@max_velocity = 10
		@rotation = 0
		cache_bounding_box
	end
	
	def hit_the_wall
		Sound["klang.wav"].play(0.1)
		@velocity_x *= -0.2
		@velocity_y = -5
		@rotation = 20
		@acceleration_y = 0.5
		@collidable = false
	end
	
	def update
		@angle += @rotation
	end
	
	def die
		destroy
	end
end
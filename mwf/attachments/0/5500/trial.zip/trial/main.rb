require 'rubygems' rescue nil
$LOAD_PATH.unshift File.join(File.expand_path(__FILE__), "..", "..", "lib")
require 'chingu'
# require 'texplay'
include Gosu
include Chingu

Dir[File.dirname(__FILE__) + '/lib/*.rb'].each {|file| require file }

# ------------------------------------------------------
# Le Main process
# Everything started here.
# ------------------------------------------------------
class Game < Chingu::Window
	def initialize
		# super(544,416)
		super(480,360)
		
		Sound["swing.wav"]
		Sound["klang.wav"]
		Sound["hit.wav"]
		Sound["grunt.wav"]
		
		retrofy # THE classy command!
		# push_game_state(Play)
		switch_game_state(Scene)
		# self.caption = "Le Trial"
	end
	
	# def update
	# end
	
	# def draw
	# end
end

# This is is important.
Game.new.show

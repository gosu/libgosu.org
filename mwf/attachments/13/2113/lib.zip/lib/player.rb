class Player
  attr_reader :score

  #The color is needed to be able to differentiate the two ships
  attr_accessor :color

  def initialize(window)
    @window = window
    @image = Gosu::Image.new(window, "media/Starfighter.bmp", false)
    @x = @y = @vel_x = @vel_y = @angle = 0.0
    @score = 0
   
    @end_game = false
    @beep = Gosu::Sample.new(window, "media/Beep.wav")
  end

  def warp(x,y)
    @x, @y = x,y
  end

  def turn_left
    @angle -= 4.5
  end

  def turn_right
    @angle += 4.5
  end

  def collect_stars(stars)
    stars.reject! do |star|
      if Gosu::distance(@x,@y,star.x,star.y) < 35 then
        @score += 10
        @beep.play(0.3,1,false)
        true
      else
        false
      end
    end
  end

  def end_game
    @end_game = true
  end

  def end_game?
    @end_game
  end

  def accelerate
    @vel_x += Gosu::offset_x(@angle, 0.5)
    @vel_y += Gosu::offset_y(@angle, 0.5)
  end

  def move
    #No more move are allowed after the game ends.
    if(!end_game?) then
      @x += @vel_x
      @y += @vel_y

      @x %= 640
      @y %= 480

      @vel_x *= 0.95
      @vel_y *= 0.95
    end
  end

  def draw
    @image.draw_rot(@x,@y,1,@angle,0.5,0.5,1,1,@color)
  end
end

#The human player use the GUI to collect input and act using the keyboard
class HumanPlayer < Player
  def get_actions
    if @window.button_down? Gosu::Button::KbLeft or @window.button_down? Gosu::Button::GpLeft then
      turn_left
    end

    if @window.button_down? Gosu::Button::KbRight or @window.button_down? Gosu::Button::GpRight then
      turn_right
    end

    if @window.button_down? Gosu::Button::KbUp or @window.button_down? Gosu::Button::GpButton0 then
      accelerate
    end
  end
end

#The computer player use the window object to fetch information on the game (the stars positions, actually)
class ComputerPlayer < Player
  #The computer strategy is very basic : it try to reach the nearest star at each moment. This
  #means that it can swith target if it pass the star, or if a new pops closer
  def get_actions
    objective = get_closest_star

    #once the closest star has been identified, the computer adjust its angle
    #and increase velocity, excepted if its already very close
    if objective != nil then
      obj_angle = Gosu::angle(@x,@y,objective.x, objective.y)
      if(obj_angle < @angle)
        turn_left
      else
        turn_right
      end

      if(Gosu::distance(@x,@y,objective.x,objective.y) > (@vel_x + @vel_y))
        accelerate
      end
    end
  end

  #Simple iteration among the stars arrays, fetching the closest, using
  #Gosu::distance. If no stars exists, the computer does nothing
  def get_closest_star
    closest_star = @window.stars.first

    if closest_star != nil then
      @window.stars.each do |star|
        if(Gosu::distance(@x,@y,star.x,star.y) < Gosu::distance(@x,@y,closest_star.x,closest_star.y))
          closest_star = star
        end
      end
    end
    return closest_star
  end

end

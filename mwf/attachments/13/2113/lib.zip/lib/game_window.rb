require 'gosu'
require 'player'
require 'star'

module ZOrder
  Background, Stars, Player, UI = *0..3
end

class GameWindow < Gosu::Window
  #The computer will need to be able to access the stars to choose its actions
  attr_reader :stars

  def initialize
    super(640, 480, false)
    self.caption = "Gosu Tutorial Game"
    
    @players = Array.new

    @background_image = Gosu::Image.new(self, "media/Space.png", true)

    @player = HumanPlayer.new(self)
    @player.warp(480,240)
    @player.color = Gosu::Color.new(0xff0000ff)

    @computer = ComputerPlayer.new(self)
    @computer.warp(160,240)
    @computer.color = Gosu::Color.new(0xffff0000)

    @players << @player
    @players << @computer
    
    @star_anim = Gosu::Image::load_tiles(self, "media/Star.png", 25, 25, false)
    @stars = Array.new

    @font = Gosu::Font.new(self, Gosu::default_font_name, 20)
  end

  def update
    #Note that nothing differs here between the human and computer players
    #All the difference is in the Player subclasses.
    @players.each do |p|
      p.get_actions
      p.move
      p.collect_stars(@stars)
    end
    
    if rand(100) < 4 and @stars.size < 25 then
      @stars.push(Star.new(@star_anim))
    end
  end

  #We define the "winner" as the first player to achieve 500 points.
  def get_winner
    @players.each do |p|
      return p if p.score >= 500
    end
    return nil
  end

  def draw
    @background_image.draw(0,0,0)

    @players.each do |p|
      p.draw
    end

    @stars.each {|star|star.draw}

    winner = get_winner
    if(winner != nil) then
      if winner == @player then
        @font.draw("Player wins with: #{@player.score}", 10, 10, ZOrder::UI, 1.0, 1.0, 0xff0000ff)
      else
        @font.draw("Computer wins with: #{@computer.score}", 10, 10, ZOrder::UI, 1.0, 1.0, 0xffff0000)
      end

      @players.each {|p| p.end_game}
    else
      @font.draw("Player score: #{@player.score}", 10, 10, ZOrder::UI, 1.0, 1.0, 0xff0000ff)
      @font.draw("Computer score: #{@computer.score}", 10, 450, ZOrder::UI, 1.0, 1.0, 0xffff0000)
    end
  end

  def button_down(id)
    if id == Gosu::Button::KbEscape
      close
    end
  end
end

window = GameWindow.new
window.show
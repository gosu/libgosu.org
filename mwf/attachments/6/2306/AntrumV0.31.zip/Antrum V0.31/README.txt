


	-----------			Made by ickylevel
	- ANTRUM -
	-----------			kurzanski.thomas@gmail.com
		
		
	VERSION 0.31
	
	-Monsters now have to attack to do damage in melee
	-Fixed important collision bug with entities (much easier to hit now)
	
	VERSION 0.3
	
	-Added spike entity
	-Added spring entity
	-Added boulder entity
	-Added possibility to have different tilesets
	-Added new sprites for the monsters
	-Added more map options to be put in the map file
		
		
	VERSION 0.2
	
	-Added configurable control keys via the menu
	-Added new sprites for the player
	-Added map options to be put in the map file
	
	
	
	-------------
	-------------
	1-Description
	2-Installation
	3-Options
	4-Gameplay
	5-Map edition
	-------------
	-------------



1-Description

	This is a 2d side scrolling platformer. It was made so it could be played on a netbook. The game is unique because
	of the monster's AI and the importance of terrain. The player can not only rely on his reflexes to play the game but have to
	find the best strategy suitable for each level. Each map is conceived as a challenge and takes hours to be completed, by trial
	and error. The very basic and easy map edition tools allows to create custom maps very easily. The mapmakers can focus on gameplay
	because maps can be created with a simple text editor : No need to match tiles manually.
	
	
2-Installation

	Just launch the executable provided with the game. Windows only. Your firewall may block the program and ruby.exe (which is also launched by the program).


	The game was created using the Ruby language and the gosu library.Ruby is an interpreted language therefore the source code of the game needs an environment to execute.
	It is bundled inside the game exe, explaining why the game takes a while to start up. Your firewall may block the program atempts to access some dlls.
	What the exe does is extracting the Ruby interpreter and required dependencies (like gosu) to a temporary file. Then it use ruby to read
	the game's source code which is also extracted.
	
	The launch time may improve in the future with the official release of ruby 2.0 and ruby2exe, thanks for your understanding.
	
3-Options

	Graphical settings are set in the config.txt file located in the game directory. 
	This file has to be edited before the game starts up.
	This file also contains the settings for the controls of the game that can be edited igame.
	
	resolution_x 500 -> vertical resolution
	resolution_y 500 -> horizontal resolution
	fullscreen 0 -> set it to 1 if you want fullscreen
	sound 0 -> the game has no sounds for now, this option is useless
	particles 1 -> values 0 1 2 , the presences of differents particles or not
	buffer 0 -> if you experiment strange effects at the edges of the screen increase it by steps of 40. 0 is for better performances.
			a value of 100 is recommanded
			
			
	Controls can be edited in the ingame menu. Press Esc to go to the previous menu once you edited all the keys you wanted.
	
4-Gameplay

	Default controls :
	-Arrows keys to move and jump
	-Spacebar to attack. Spacebar + down button to attack down.
	-Alt for secondary attack
	-Enter and Escape to navigate menus.
	-To move backward , hold down button
	
5-Map edition

	Maps are located in the simplemaps directory.
	A text editor such as notepad++ or ascii painter is recommanded.
	
	Every symbol that is not described here is interpreted as a blank space.
	/!\ The length of the first line determine the length of the level.
	Height is related to the number of lines.
	
	x : A square filled with dirt (destructible)
	r : A square filled with indestructible rocks.
	
	l : A fast green monster (its an L)
	c : A strong big monster
	t : A ranged attack monster
	y : The basic monster
	w : A stronger version of the basic monster
	b : A flying monster

	
	
	p : The player starting postion (important)
	s : A checkpoint for the player
	e : End of level
	i : Spikes that hurt
	< : A boulder that will go left
	> : A boulder that will go right
	_ : A spring (makes things jump)
	) : A right faced spring
	( : A left faced spring
	
	d : Dynamite powerup
	h : One life ...
	
	
	You can add parameters before you write the map (they are all optionnal) :
		
	:description Worst shittiest map ever.	=> The description that appear in the map menu
	:death_msg Loooooooooser !
	:win_msg You win lololololol !
	:start_msg Welcome to this map ! 
	:gravity 0.8
	:max_speed_fall 35
	:jump 30 => jump force of the player
	:speed 0.4 => speed of the player
	:map 						=> Used to indicate when the map drawing beggins
	xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
	xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
	xxx            xxxxxxxxxxxxxx
	xxx     p            xxxxxxxx
	xx                     xxxxxx
	


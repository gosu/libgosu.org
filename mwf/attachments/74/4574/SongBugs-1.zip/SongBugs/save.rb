require 'patches.rb'

class Map_File
	def initialize(bugs, tiles)
		@objects = Array.new
		@objects << bugs << tiles
	end
	
	def save
		File.open "My Song.sbsong", "w" do |f|
			@objects.flatten.each {|obj|
				unless obj.in_pallette?
					f.print "#{obj.dump_information}\n"
				end}
		end
	end
	
	def self.load_into(window)
																				# Open the save file to read
		File.open "My Song.sbsong", "rb" do |f|
			$data = f.read.to_s.split("\n")
			$objects = $data.collect {|string|
				if string[0..1] == "b;"
					$class = Bug
				elsif string[0..1] == "t;"
					$class = Tile
				end
				$class.load_information(window, string)}
			$bugs = $tiles = Array.new
			$objects.each {|obj|
				if obj.class == Bug
					$bugs << obj
				elsif obj.class == Tile
					$tiles << obj
				end}
		end
		
		$objects.compact!
		window.clear_all
		window.add_bugs($bugs)
		window.add_tiles($tiles)
		puts
	end
end
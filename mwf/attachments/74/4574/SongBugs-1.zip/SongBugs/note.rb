class Note	#I am just a storage place for a note name, and I know what color represents me, and the pallette position for any tile that uses my note
	def initialize(window, note_name)							#initialize me
		@window = window
		@note_name = note_name.to_sym
		set_window(window)
	end
	
	def set_window(new)
		unless new == nil
			@window = new
			@sample = Gosu::Sample.new(@window, "sounds/" + @note_name.to_s + ".wav")
			@colors = Array.new
			
			$black = [:rest, Gosu::Color.rgb(0, 0, 0), 2]			#the 1st object is the note name. the 2nd is the note color. the 3rd and final object represents the slot position for that note. this goes for all color arrays
			@colors << $black
			
			$red = [:A4, Gosu::Color.rgb(255, 0, 0), 4]
			@colors << $red
			
			$light_red = [:As4, Gosu::Color.rgb(255, 0, 127), 5]
			@colors << $light_red
			
			$orange = [:B4, Gosu::Color.rgb(255, 127, 0), 6]
			@colors << $orange
			
			$yellow = [:C4, Gosu::Color.rgb(255, 255, 0), 7]
			@colors << $yellow
			
			$yellow_green = [:Cs4, Gosu::Color.rgb(127, 255, 0), 8]
			@colors << $yellow_green
			
			$green = [:D4, Gosu::Color.rgb(0, 255, 0), 9]
			@colors << $green
			
			$blue_green = [:Ds4, Gosu::Color.rgb(0, 255, 127), 10]
			@colors << $blue_green
			
			$cyan = [:E4, Gosu::Color.rgb(0, 255, 255), 11]
			@colors << $cyan
			
			$light_blue = [:F4, Gosu::Color.rgb(0, 196, 255), 12]
			@colors << $light_blue
		
			$blue = [:Fs4, Gosu::Color.rgb(0, 0, 255), 13]
			@colors << $blue
			
			$purple = [:G4, Gosu::Color.rgb(127, 0, 255), 14]
			@colors << $purple
			
			$pink = [:Gs4, Gosu::Color.rgb(255, 127, 255), 15]
			@colors << $pink
		end
	end
	
	def _dump
		@note_name
	end
	
	def note_name
		@note_name
	end
	
	def name_color
		@colors.each {|color_array| 	if (color_array.at(0) == @note_name.to_sym)
											$color = color_array.at(1)
										end}
		if $color == nil
			$color = Gosu::Color.rgb(0, 0, 0)
		end
		
		$color
	end
	
	def name_slot_x
		@colors.each {|color_array|		if (color_array.at(0) == @note_name.to_sym)
											$slot_x = color_array.at(2)
										end}
		$slot_x
	end
	
	def play(p)
		#@sample.play_pan(pan=p, vol=1)
		@sample.play(1)
	end
end
require 'note.rb'

class Tile
	def initialize(window, note_name, in_pallette = false, pallette = nil)	#initialization
		@note_name = note_name
		set_window(window)
		@in_pallette = in_pallette
		@x = 20
		@y = 20
		@being_dragged = false
	end
	
	def set_window(new)
		unless new == nil
			@window = new
			@note = Note.new(@window, @note_name)
			@image = Gosu::Image.new(@window, "images/tile.png", false)
			@color = @note.name_color
		end
	end
	
	def dump_information
		"t;#{note_name};#{x};#{y}"
	end
	
	def self.load_information(window, data)
		$attributes = data.split(";")
		$new_tile = self.new(window, $attributes[1], false)
		$new_tile.x($attributes[2].to_i)
		$new_tile.y($attributes[3].to_i)
		$new_tile
	end
	
	#def _dump(depth)
	#	[@note_name, @in_pallette, x, y].join ";"
	#end
	
	#def self._load(data)
	#	$attributes = data.split ";"
	#	$newtile = self.new(nil, $attributes[0], $attributes[1])
	#	$newtile.x($attributes[2])
	#	$newtile.y($attributes[3])
	#end
	
	def update
		@color = @note.name_color
		if @in_pallette
			@x = slot_x(@note.name_slot_x)
			@y = slot_y
		end
	end
	
	def draw
		if @in_pallette
			if not playing?
				@image.draw(@x, @y, 1, 1, 1, @color)
			end
		else
			@image.draw(@x, @y, 1, 1, 1, @color)
		end
	end
	
	def on
		play
	end
	
	def off
	end
	
	def is_bug
		false
	end
	
	def in_pallette?
		@in_pallette
	end
	
	def x(new_x = @x)
		@x = new_x
	end
	
	def y(new_y = @y)
		@y = new_y
	end
	
	def width
		@image.width
	end
	
	def height
		@image.height
	end
	
	def slot_x(slot_num)
		@window.slot_x(slot_num)
	end
	
	def slot_y
		@window.slot_y
	end
	
	def note_name
		@note.note_name
	end
	
	def being_dragged(new_being_dragged = @being_dragged)
		@being_dragged = new_being_dragged
	end
	
	def play
		$p = (@x - (@window.width / 2)) / (@window.width)
		@note.play($p)
	end
	
	def playing?
		@window.playing?
	end
end
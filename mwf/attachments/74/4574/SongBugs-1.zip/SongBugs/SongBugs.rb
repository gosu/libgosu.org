#SongBugs, by J. Wostenberg 2011

$LOAD_PATH.unshift File.dirname(__FILE__)

require 'rubygems'
require 'gosu'
require 'cursor.rb'
require 'pallette.rb'
require 'bug.rb'
require 'tile.rb'
require 'save.rb'

class GameWindow < Gosu::Window
	def self.open
		self.new.show
	end
	
	def initialize
		super(900, 900, false)
		self.caption = "SongBugs"
		@cursor = Cursor.new(self)
		@bugs = Array.new
		@tiles = Array.new
		@pallette = Pallette.new(self)
		@bkg_color = Gosu::Color.rgb(255, 255, 255)
																				# Set the number of "slots" in the pallette
		@slots = 16
		@playing = false
		@interval = 10
		
																				# Initialize the bugs and tiles
		add_pallette_bug
		add_pallette_tiles
		
	end
	
	def update
		@tiles.compact!
																				# Clear the non-pallette bugs and tiles if C is pressed
		if button_down?(Gosu::Button::KbC)
			clear_all
		end
		
		if (button_down?(Gosu::Button::KbSpace)) and @interval > 20
			if @playing
				@playing = false
			else
				@playing = true
			end
			@interval = 0
		end
		
		@interval = @interval + 1
		
		if @playing == true
			@bkg_color = Gosu::Color.rgb(255, 255, 255)
		else
			@bkg_color = Gosu::Color.rgb(220, 220, 220)
		end
		
																				# Update the cursor, pallette, bugs, and tiles
		[@cursor, @pallette, @bugs, @tiles].flatten.each {|each| each.update}
		
		if button_down?(Gosu::Button::KbS)
			save_world
		end
		
		if button_down?(Gosu::Button::KbL)
			load_world
		end
	end
	
	def draw
																				# Draw the cursor, pallette, bugs, and tiles
		[@cursor, @pallette, @bugs, @tiles].flatten.each {|each| each.draw}
		
		draw_quad(0, 0, @bkg_color,  self.width, 0, @bkg_color,  0, self.height, @bkg_color,  self.width, self.height, @bkg_color, -1)
	end
	
	def save_world
		$wf = (Map_File.new(@bugs, @tiles)).save
	end
	
	def load_world
		$wf = Map_File.load_into(self)
	end
	
	def bugs
		@bugs
	end
	
	def tiles
		@tiles
	end
	
																				# Is the left mouse button down?
	def l_mouse_down?
		button_down?(Gosu::Button::MsLeft)
	end
	
																				# Is the right mouse button down?
	def r_mouse_down?
		button_down?(Gosu::Button::MsRight)
	end
	
																				# Add the given bug to the bugs list
	def add_bug(bug)
		@bugs << bug
	end
	
	def add_tile(tile)
		@tiles << tile
	end
	
																				# Add multiple bugs
	def add_tiles(ary)
		@tiles << ary
		@tiles.flatten!
	end
	
																				# Add multiple tiles
	def add_bugs(ary)
		@bugs << ary
		@bugs.flatten!
	end
	
	def slots
		@slots
	end
	
	def clear_all
																				# Delete ALL bugs
		@bugs.clear
																				# Delete ALL tiles	
		@tiles.clear
		add_pallette_bug
		
		add_pallette_tiles
	end
	
	def add_pallette_bug
		add_bug(Bug.new(self, true, @pallette))
	end
	
	def add_pallette_tiles
		add_tiles(	[Tile.new(self, :A4, true, @pallette),
					Tile.new(self, :As4, true, @pallette),
					Tile.new(self, :B4, true, @pallette),
					Tile.new(self, :C4, true, @pallette),
					Tile.new(self, :Cs4, true, @pallette),
					Tile.new(self, :D4, true, @pallette),
					Tile.new(self, :Ds4, true, @pallette),
					Tile.new(self, :E4, true, @pallette),
					Tile.new(self, :F4, true, @pallette),
					Tile.new(self, :Fs4, true, @pallette),
					Tile.new(self, :G4, true, @pallette),
					Tile.new(self, :Gs4, true, @pallette),
					Tile.new(self, :rest, true, @pallette)])
	end
	
	def slot_x(slot_num)
		@pallette.x + (((width / slots) * slot_num) + 10)
	end
	
	def slot_y
		@pallette.y + ((@pallette.height / 2) - (20 / 2))
	end
	
	def pallette
		@pallette
	end
	
	def playing?
		@playing
	end
end

GameWindow.open													#start the game!
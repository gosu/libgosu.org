class Cursor
	def initialize(window)
		@window = window														#initialize me
		@image = Gosu::Image.new(@window, "images/cursor.png", false)
		@x = 0
		@y = 0
		@dragged = nil
	end
	
	def update
		@x = mouse_x
		@y = mouse_y
		
		if not playing?																										#only if the song is not playing
			[tiles, bugs].flatten.reverse.each {|obj| 	if ((touching(obj) and @dragged == nil) and l_mouse_down?)			#test if I am touching obj and I am not dragging anything, AND the left mouse button is down 
															if (obj.in_pallette?) or shift_down?							#test if "obj" is part of the pallette or shift is down
																	obj.on													#turn it on
																
																if (obj.is_bug)
																	$new_obj = Bug.new(@window)								#create and add a new bug
																	$new_obj.direction(obj.direction?)
																	bugs << $new_obj
																else
																	$new_obj = Tile.new(@window, obj.note_name)
																	tiles << $new_obj										#create and add a new tile 
																end
															
																@dragged = $new_obj											#start dragging the new object
															else
																@dragged = obj												#if on the other hand, obj is NOT part of the pallette, then just drag it		
															end
															elsif ((touching(obj) and @dragged == nil) and r_mouse_down?)	#test if I am touching obj and I am not dragging anything, AND the right mouse button is down
																bugs.delete(obj)											#try to delete obj as a bug
																tiles.delete(obj)											#try to delete obj as a tile
														end}
		
			bugs.reverse.each {|bug|	if touching(bug)
											if button_down?(Gosu::Button::KbUp)
												bug.direction(0)
											end
											
											if button_down?(Gosu::Button::KbDown)
												bug.direction(2)
											end
											
											if button_down?(Gosu::Button::KbRight)
												bug.direction(1)
											end
											
											if button_down?(Gosu::Button::KbLeft)
												bug.direction(3)
											end
										end}
		end
		
		if not l_mouse_down?																			#if the mouse is up
			@dragged = nil																				#drop the currently dragged object
			[bugs, tiles].flatten.each {|obj|	if obj.in_pallette?										#tell all the bugs in the pallette to turn off
													obj.off
												end}
												
			[bugs, tiles].flatten.each {|obj|	if (not obj.in_pallette?) and (not @dragged == obj) and ((obj.y + obj.height) > pallette.y)		#if obj is not part of the pallette, obj is not being dragged, and obj is inside the pallette
													bugs.delete(obj)									#try to delete obj as a bug
													tiles.delete(obj)									#try to delete obj as a tile
												end}
		end
		
		if @dragged != nil
			@dragged.x(round_from_to(mouse_x - 10, 20))			#snap-to grid code! :D
			@dragged.y(round_from_to(mouse_y - 10, 20))
		end
	end
	
	def draw
		@image.draw(@x, @y, 3)
	end
	
	def mouse_x
		@window.mouse_x
	end
	
	def mouse_y
		@window.mouse_y
	end
	
	def bugs
		@window.bugs											#return all the bugs
	end
	
	def tiles
		@window.tiles											#return all the tiles
	end
	
	def width
		@image.width
	end
	
	def height
		@image.height
	end
	
	def touching(object)										#returns if I am touching the given object (HAS TO HAVE AN X AND Y METHOD)
		(((mouse_x > object.x) and (mouse_x < object.x + object.width)) and ((mouse_y > object.y) and (mouse_y < object.y + object.width)))
	end
	
	def round_from_to(num, round)								#round "num" to "round"
		((num / round).round) * round
	end
	
	def l_mouse_down?
		@window.l_mouse_down?
	end
	
	def r_mouse_down?
		@window.r_mouse_down?
	end
	
	def add_bug(bug)											#tell the window to add the given bug to the bugs list
		@window.add_bug(bug)
	end
	
	def pallette
		@window.pallette
	end
	
	def playing?
		@window.playing?
	end
	
	def button_down?(id)
		@window.button_down?(id)
	end
	
	def shift_down?
		button_down?(Gosu::KbLeftShift) or button_down?(Gosu::KbRightShift)
	end
end
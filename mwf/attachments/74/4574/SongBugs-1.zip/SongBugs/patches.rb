class NilClass
	def dump_information
		""
	end
end
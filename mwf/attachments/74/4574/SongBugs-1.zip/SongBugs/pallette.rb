class Pallette
	def initialize(window)										#initialize me
		@window = window
		
		@image = Gosu::Image.new(@window, "images/pallette.png", false)
		@y = @window.height - @image.height
		@x = 0
	end
	
	def update
	end
	
	def draw
		if (not playing?)
			@image.draw(0, @y, 0)
		end
	end
	
	def x
		@x
	end
	
	def y
		@y
	end
	
	def width
		@image.width
	end
	
	def height
		@image.height
	end
	
	def bugs
		@window.bugs
	end
	
	def tiles
		@window.tiles
	end
	
	def playing?
		@window.playing?
	end
end
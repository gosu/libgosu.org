$LOAD_PATH.unshift "."


require "yaml"
require "gosu"


# Describes a basic 2D vector
class Vector
  PI = 3.141592653589793238462643383
  TWOPI = PI * 2.0
  
  attr_accessor :x, :y
  
  def self.from_angle_and_length(angle, length)
    angle_r = (angle - 90) * (PI / 180.0)
    x = Math.cos(angle_r) * length
    y = Math.sin(angle_r) * length
    if y > 0
      Vector.new(-x, y)
    else
      Vector.new(x, y)
    end
  end
  
  def initialize(x = 0.0, y = 0.0)
    @x = x
    @y = y
  end
  
  def add(v)
    @x += v.x
    @y += v.y
  end
  
  def magnitude 
    Math.hypot @x, @y
  end
end

class GameWindow < Gosu::Window
  SCR_WIDTH = 800
  SCR_HEIGHT = 600

  MODE_START = 1
  MODE_PLAY = 2
  MODE_CRASH = 3
  MODE_LAND = 4
  
  COLOR_GREEN = 0xff00ff00
  COLOR_RED = 0xffff0000
  
  def initialize
    @game_state = MODE_START
    @frame_count = 0
    @start_milliseconds = Gosu::milliseconds
    
    config = nil
    
    # load the configuration file
    begin
      data = File.read "config.yml"
      config = YAML.load data
    rescue
      puts "Could not read configuration file, exiting"
      exit
    end

    @gravity = Vector.new 0.0, config["gravity"]
    @thrust = config["thrust"]
    @player_fuel = config["fuel"]
    
    super SCR_WIDTH, SCR_HEIGHT, false
    self.caption = "My first Gosu game test"
    
    @background = Gosu::Image.new self, "img/background.png", true
    @player_img = Gosu::Imvectage.new self, "img/lander.png", true
    @font = Gosu::Font.new(self, Gosu::default_font_name, 20)
#    @music = Gosu::Song.new(self, "music/song.m4a")
    @thrust_sound = Gosu::Sample.new self, "sounds/thrust.wav"
    @thrusting = nil
#    @music.play

    reset_player
  end


  def reset_player
    @player_x = 400
    @player_y = 200
    @player_angle = 0
    @player_vector = Vector.new
  end
  
  
  def update
    case @game_state
    when MODE_START
      update_start
    when MODE_PLAY
      update_play
    when MODE_CRASH
      update_start
    when MODE_LAND
      update_start
    end
  end
  
  def update_start
    if button_down? Gosu::KbSpace
      @game_state = MODE_PLAY
      reset_player
    end
  end
  
  
  def update_play
    if button_down? Gosu::KbLeft
      @player_angle -= 5
    end
    if button_down? Gosu::KbRight
      @player_angle += 5
    end

    @player_angle += 360 if @player_angle < 0
    @player_angle -= 360 if @player_angle >= 360
    
    if button_down? Gosu::KbSpace and @player_fuel > 0
      v = Vector.from_angle_and_length(@player_angle, @thrust)
      @player_vector.add v
      @player_fuel -= 1
      
      # If not already making thrust noise, start it
      if @thrusting.nil?
        @thrusting = @thrust_sound.play 1, 1, true
      end
      else
      unless @thrusting.nil?
        @thrusting.stop
        @thrusting = nil
      end
    end
    
    @player_vector.add @gravity
    @player_x += @player_vector.x
    @player_y += @player_vector.y
    
    @player_x -= SCR_WIDTH if @player_x > SCR_WIDTH
    @player_x += SCR_WIDTH if @player_x < 0

    # Check for landing conditions
    if @player_y > 575
      if (@player_angle < 10 or @player_angle > 350) and @player_vector.magnitude < 1.0
        @game_state = MODE_LAND
      else
        @game_state = MODE_CRASH
      end
    end
  end
  
  
  def draw
    case @game_state
    when MODE_START
      draw_start
    when MODE_PLAY
      draw_play
    when MODE_CRASH
      draw_start "You crashed!"
    when MODE_LAND
      draw_start "You landed!"
    end
    @frame_count += 1
    fps = (@frame_count * 1000.0) / milliseconds
    @font.draw "FPS: #{sprintf('%0.02f', fps)} (#{milliseconds}) (#{@frame_count})", 10, 570, 3, 1.0, 1.0, COLOR_GREEN
  end
  
  def draw_start(msg = nil)
    @background.draw 0, 0, 0

    unless msg.nil?
      @font.draw msg, 100, 370, 3, 1.0, 1.0, COLOR_GREEN
    end
    @font.draw "Press the spacebar to start", 100, 400, 3, 1.0, 1.0, COLOR_GREEN
  end


  def draw_play
    @background.draw 0, 0, 0
    
    @player_img.draw_rot @player_x, @player_y, 1, @player_angle
    color = @player_fuel > 100 ? COLOR_GREEN : COLOR_RED
    @font.draw "Fuel: #{@player_fuel}", 700, 5, 3, 1.0, 1.0, color
  end


  
  def button_down(key_id)
    close if key_id == Gosu::KbEscape
  end
  
  
  def milliseconds
    Gosu::milliseconds - @start_milliseconds
  end
  

end

def main
  window = GameWindow::new
  window.show
end

main
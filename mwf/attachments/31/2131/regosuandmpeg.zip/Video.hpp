
#ifndef GOSU_ADDON_VIDEO_HPP
#define GOSU_ADDON_VIDEO_HPP

#include <Gosu/Gosu.hpp>
#include <Gosu/AutoLink.hpp>

#include <boost/scoped_array.hpp>
#include <boost/scoped_ptr.hpp>

extern "C" {
#include <ffmpeg/avcodec.h>
#include <ffmpeg/avformat.h>
#include <ffmpeg/swscale.h>
}


#include <GL/gl.h>

#include <string>

namespace GosuAddon {

    //! a Gosu-style Video class
    class Video : public Gosu::Image
    {
    private:
        // file
        AVFormatContext * pFile;
        // codec_context
        //AVCodecContext * pStream;
        AVStream * pStream;
        AVCodec * pCodec;
        AVFrame * pFrame;
        AVFrame * pFrameRGB;
        SwsContext * converter;

        // to synchronize timing
        unsigned long lastframe;
        int ms_per_frame;
        int skip_frames;
        unsigned long frame_index; // resets when the video begins at the beginning
        unsigned long max_frame_index; // only valid once the video played a full time
        // loop video if ends?
        bool loop;
        // stream index of the video
        int videoStream;
        // information about the texture
        int texWidth, texHeight;
        boost::scoped_array<uint8_t> image_clone;
        boost::scoped_array<uint8_t> buffer;
    public:
        ~Video();
        //! creates a Video from filename
        Video(Gosu::Graphics & graphics, std::wstring filename, bool loop = true);
        //! enable or disable looping
        void enableLooping(bool loop = true);
        //! seek target ms forward
        void seek(unsigned long target);
        //! get the current time in ms of the video
        unsigned long time() const;
        //! get the length of the video in ms
        unsigned long length() const;
        //! loads the next frame of the Video if enough time has passed for the next frame
        void update();
    }; // class Video

}; // namespace GosuAddon

#endif

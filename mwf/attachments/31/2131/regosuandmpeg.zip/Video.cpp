
#include "Video.hpp"


#ifdef DEBUG_ON
#include <iostream>
#endif


GosuAddon::Video::
~Video()
{
    // free temporary frame
    av_free(pFrameRGB);
    // free colorspace converter
    sws_freeContext(converter);

    // Free the input frame
    av_free(pFrame);

    // Close the codec
    avcodec_close(pStream -> codec);

    // Close the video file
    av_close_input_file(pFile);

}

GosuAddon::Video::
Video(Gosu::Graphics & graphics, std::wstring filename, bool loop)
    :Image(),
    pFile(0), pStream(0), pCodec(0), pFrame(0),
    lastframe(0), loop(true), skip_frames(0), frame_index(0), max_frame_index(0)
{
    std::cout << "blub" << std::endl;
    enableLooping(loop);
    
    //TODO: call only once
    // register all codecs
    av_register_all();

    // open file
    if(av_open_input_file(&pFile, std::string(filename.begin(), filename.end()).c_str(), NULL, 0, NULL))
        throw(std::runtime_error("Cannot open file: " + std::string(filename.begin(), filename.end())));
    
    // find streams in file
    if(av_find_stream_info(pFile) < 0)
        throw(std::runtime_error("No streams found in file: " + std::string(filename.begin(), filename.end())));
    
    /* find video stream */
    videoStream = -1;
#ifdef DEBUG_ON
    std::cout << "Number of Streams: " << pFile -> nb_streams << std::endl;
#endif
    // Find the first video stream
    for(int i = 0; i < pFile -> nb_streams; i++) {
        if(pFile -> streams[i] -> codec -> codec_type == CODEC_TYPE_VIDEO) {
            videoStream = i;
            break;
        }
    }
#ifdef DEBUG_ON
    std::cout << "Stream Index: " << videoStream << std::endl;
#endif
    if(videoStream == -1)
        throw(std::runtime_error("No video stream found in file: " + std::string(filename.begin(), filename.end())));

    // Get a pointer to the codec context for the video stream
    //pStream = pFile -> streams[videoStream] -> codec;
    pStream = pFile -> streams[videoStream];
    
    /* end find video stream */

    // Find the decoder for the video stream
    pCodec = avcodec_find_decoder(pStream -> codec -> codec_id);
    if(!pCodec) {
        throw(std::runtime_error("Unsupported video codec"));
    }
    // Open codec
    if(avcodec_open(pStream -> codec, pCodec) < 0)
        throw(std::runtime_error("Cannot open codec"));

    // initialize colorspace converter
    converter = sws_getContext( pStream -> codec -> width, pStream -> codec -> height, pStream -> codec -> pix_fmt,
                                //pStream -> codec -> width, pStream -> codec -> height, PIX_FMT_RGB24, SWS_BICUBIC,
                                pStream -> codec -> width, pStream -> codec -> height, PIX_FMT_RGB24, SWS_BICUBIC,
                                //pStream -> codec -> width, pStream -> codec -> height, PIX_FMT_RGBA, SWS_BICUBIC, // not working :(
                                NULL, NULL, NULL);

#ifdef DEBUG_ON
    // print information about stream
    std::cout << "Pixel Format: " << pStream -> codec -> pix_fmt << std::endl;
    std::cout << "Codec Name: " << pCodec -> name << std::endl;
    std::cout << "Size: " << pStream -> codec -> width << "x" << pStream -> codec -> height << std::endl;
    std::cout << "FrameNumber: " << pStream -> codec -> frame_number << std::endl;
    std::cout << "FrameSize: " << pStream -> codec -> frame_size << std::endl;
    std::cout << "dts: " << pStream -> cur_dts << std::endl;
    std::cout << "TimeBase: " << av_q2d(pStream -> codec -> time_base) << "( " << pStream -> codec -> time_base.num << "/" << pStream -> codec -> time_base.den << ")" << std::endl;
    std::cout << "Aspect: " << pStream -> codec -> sample_aspect_ratio.num << "x" << pStream -> codec -> sample_aspect_ratio.den << std::endl;
    std::cout << "DVB MPEG2 aspect info: " << pStream -> codec -> dtg_active_format << std::endl;
    std::cout << "Start Time: " << pStream -> start_time << std::endl;
    //std::cout << "Duration: " << length() << std::endl;
    std::cout << "Num Frames: " << pStream -> nb_frames << std::endl;
#endif
    ms_per_frame = av_q2d(pStream -> codec -> time_base) * 1000;
    // Allocate video frame
    pFrame = avcodec_alloc_frame();
    
    pFrameRGB = avcodec_alloc_frame();
    //*
    int numBytes = avpicture_get_size(PIX_FMT_RGB24, pStream -> codec -> width, pStream -> codec -> height);
    buffer.reset(new uint8_t[numBytes]);
    avpicture_fill((AVPicture*)pFrameRGB, buffer.get(), PIX_FMT_RGB24, pStream -> codec -> width, pStream -> codec -> height);
    // */
    /*
    // not working :(
    int numBytes = avpicture_get_size(PIX_FMT_RGBA, pStream -> width, pStream -> height);
    buffer.reset(new uint8_t[numBytes]);
    avpicture_fill((AVPicture*)pFrameRGB, buffer.get(), PIX_FMT_RGBA, pStream -> width, pStream -> height);
    */
    

    // Allocate Texture space through gosu
    Gosu::Bitmap bmp;
    Gosu::Color alpha(0.0, 0.0, 0.0, 0.0);
    bmp.resize(pStream -> codec -> width, pStream -> codec -> height, alpha);
    data.reset(graphics.createImage(bmp, 0, 0, pStream -> codec -> width, pStream -> codec -> height, Gosu::bfHard).release());
    
    #warning using opengl to read values, try doing this through gosu
    glEnable(GL_TEXTURE_2D);
    glBindTexture( GL_TEXTURE_2D, data -> glTexInfo() -> texName); // get options from gosu-texture, do this a better way some day?
    glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_WIDTH, &texWidth);
    glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_HEIGHT, &texHeight);
    glDisable(GL_TEXTURE_2D);
    image_clone.reset(new uint8_t[texWidth * texHeight * 4]);
}


void
GosuAddon::Video::
enableLooping(bool loop)
{
    this -> loop = loop;
}

void
GosuAddon::Video::
seek(unsigned long target)
{
    skip_frames = target/ms_per_frame;
}

unsigned long
GosuAddon::Video::
time() const
{
    return frame_index * ms_per_frame;
}


unsigned long
GosuAddon::Video::
length() const
{
    return max_frame_index * ms_per_frame;
}

void
GosuAddon::Video::
update()
{
    // wait for next video frame
    if(lastframe + ms_per_frame > Gosu::milliseconds()) {
        return;
    } else {
        // too much time passed since last frame was processed
        if(lastframe + 2*ms_per_frame < Gosu::milliseconds()) {
            // has lastframe not been set yet?
            if(lastframe) {
                // skip enough frames to catch up
                skip_frames = (Gosu::milliseconds() - lastframe)/ms_per_frame;
            } else {
                // first setup!
                lastframe = Gosu::milliseconds();
            }
        }
        lastframe += ms_per_frame;
    }
    
    AVPacket packet;

    // skip frames
    while(skip_frames > 0) {
        printf("skip frames: %d\n", skip_frames);
        // failed to get a package? probably finished with the stream
        if(av_read_frame(pFile, &packet) < 0) {
            lastframe = Gosu::milliseconds();
            break;
        }
        frame_index++; // increase frame index

#ifdef GOSUADDON_DO_FULL_SEEKING
        if(packet.stream_index == videoStream) {
            int frameFinished;
            avcodec_decode_video(pStream -> codec, pFrame, &frameFinished, packet.data, packet.size);
            if(frameFinished)
                av_free_packet(&packet);
        }
#endif // gosu addon do full seeking

        skip_frames--;
    }

    /* read a new frame and redraw it on the texture */
    // got a frame?
    if(av_read_frame(pFile, &packet) >= 0) {
        frame_index++; // increase frame index
        /* begin evil hack */
        bool abort = false;
#warning evil hack to get videos to run properly, even if they have a lot of non-video frames in them
        while(packet.stream_index != videoStream) {
            av_free_packet(&packet);
            if(av_read_frame(pFile, &packet) < 0) {
                abort = true;
                break;
            }
        }

        // has video?
        if(!abort &&(packet.stream_index == videoStream)) {
            /* end evil hack */
            int frameFinished;
            // decode next frame
            avcodec_decode_video(pStream -> codec, pFrame, &frameFinished, packet.data, packet.size);
            // actually got a frame from video?
            
            if(frameFinished) {
//#error this might fail
                Gosu::GLTexInfo info = data -> glTexInfo() . get();
                // get texture
                glEnable( GL_TEXTURE_2D);
                glBindTexture( GL_TEXTURE_2D, info . texName );  // use previously created texture object and set options
                glGetTexImage( GL_TEXTURE_2D, 0, GL_RGBA, GL_UNSIGNED_BYTE, image_clone.get()); // get full texture
                // iterators for texture and frame
                uint8_t* target, *source;
                
                // texture coordinates, from percentage to direct index
                int left = info . left * texWidth;
                int top = info . top * texHeight;
                int right = info . right * texWidth;
                int bottom = info . bottom * texHeight;
                sws_scale(converter, pFrame -> data, pFrame -> linesize, 0, pStream -> codec -> height,
                        pFrameRGB->data, pFrameRGB->linesize);
                        //&image_clone[texWidth*top*4 + left*4], texWidth);
                for(int y = 0; y < pStream -> codec -> height; y++) {
                    target = &image_clone[texWidth * (y + top) * 4 + left * 4];
                    source = (pFrameRGB -> data[0]) + (pFrameRGB -> linesize[0])*y;
                    for(int x = 0; x < pStream -> codec -> width; x++) {
                        for(int c = 0; c < 3; c++) {
                            *target = *source;
                            source++;
                            target++;
                        }
                        *target = 255;
                        target++;
                    }
                }
                // draw texture back
                glTexImage2D ( GL_TEXTURE_2D, 0, GL_RGBA, texWidth, texHeight, 0,
                             GL_RGBA, GL_UNSIGNED_BYTE, image_clone.get());
                // done with textures
                glDisable(GL_TEXTURE_2D);

            }
        }
        // free packet
        av_free_packet(&packet);
    } else {
        if(loop)
            av_seek_frame(pFile, videoStream, 0, 0);
    }
}

#!/bin/sh
sudo apt-get install libavcodec-dev libavformat-dev

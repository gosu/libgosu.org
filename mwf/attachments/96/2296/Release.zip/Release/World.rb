




class Entity
    attr_reader  :x , :y
    attr_accessor :hitbox , :status ,:images
    def initialize()

        @x = 0
        @y = 0



        @hitbox = RectangleBox.new(40,40)

        @images = Array.new

        @status = 0

    end

    def create(world,x,y)

        nx = world.gddx(x)
        ny = world.gddy(y)


        world.getzone(x,y).add(self)

        if world.full_calculus == true then
           world.Ents.push(self)
        end


        @x = nx
        @y = ny
    end


    def teleport(world,x,y)

        nx = world.gddx(x)
        ny = world.gddy(y)

        w1 = world.getzone(@x,@y)
        w2 = world.getzone(x,y)

        if w1 != w2 then
            world.getzone(@x,@y).remove(self)
            world.getzone(x,y).add(self)
        end



        @x = nx
        @y = ny
    end

    def check_collide(ent)
        return @hitbox.check_collide(@x,@y, ent.hitbox , ent.x,ent.y)
    end

    def check_hit_melee(ent)
	return @hitbox.check_hit_melee(@x,@y,ent.melee_range,ent.x,ent.y)
    end

    def destroy(world)
        if world.full_calculus == false then
            world.getzone(@x,@y).remove(self)
        else
            world.getzone(@x,@y).remove(self)
            world.Ents.delete(self)
        end
    end

   def check_collide_world(x,y,wx,wy,sq)
        return @hitbox.check_collide_world(x,y,wx,wy,sq)
    end

    def check_collide_world_slope(x,y,wx,wy,sq,kind)
        return @hitbox.check_collide_world_slope(x,y,wx,wy,sq,kind)
    end



end


class PhysEnt < Entity
    attr_accessor :falling , :vel_x , :vel_y, :friction
    def initialize()
        super()
        @vel_x = @vel_y = 0.0
        @friction = 0.95
        @bouncyness = 0
        @falling = 3

    end

    def accx(offset)
        @vel_x += offset

        # pour ne pas aller plus vite qu'un sq par frame
        if @vel_x > 40 then
            @vel_x = 40
        elsif @vel_x < -40 then
            @vel_x = -40
        #elsif @vel_x.abs < 0.3 then
           # @vel_x = 0
        end

    end

    def accy(offset)
        @vel_y += offset

        # pour ne pas aller plus vite qu'un sq par frame
        if @vel_y > 40 then
            @vel_y = 40
        elsif @vel_y < -40 then
            @vel_y = -40

       # elsif @vel_y.abs < 0.3 then
            #@vel_y = 0
        end

    end

    def push(speed,angle)
        accx(Gosu::offset_x(angle, speed))
        accy(Gosu::offset_y(angle, speed))
    end

    def apply_friction()
        @vel_x *= @friction
        @vel_y *= @friction
    end

    def apply_gravity(gravity,max_speed_fall)

        if @vel_y > max_speed_fall then
            return
        elsif @vel_y < -max_speed_fall then
            return
        end

        accy(gravity)

    end

    def touch_ground(world)
        @falling = 3
    end
    def main_move(world)

        apply_gravity(world.gravity,world.max_speed_fall)
        apply_friction()
        move(world,@x + @vel_x ,@y + @vel_y )

    end

    def move(world,x,y) # plutot high level

        # on fait du cas par cas
        # du coup on peut pas aller plus vite qu'un sq

        newx = x
        newy = y

        delta = 40

        ix = world.gdx(x-delta)
        fx = world.gdx(x+delta)

        iy = world.gdy(y-delta)
        fy = world.gdy(y+delta)
        @falling -= 1

        # on ne teste que les cases adjacentes
        (ix..fx).each do |xx|
            (iy..fy).each do |yy|


                if  ( world.getzone_direct(xx,yy).Kind == 2 or world.getzone_direct(xx,yy).Kind == 3 ) and check_collide_world_slope(x,y,xx*world.sq,yy*world.sq,world.sq,world.getzone_direct(xx,yy).Kind) then

                       if  world.getzone_direct(xx,yy).Kind == 3  then
                           #droite montant

                          pre_newy = (yy+1)*world.sq - @hitbox.get_surface_offset_y() - @hitbox.difference_slope_y(xx,yy,world.sq,x,y)
                          if pre_newy < newy  then
                              newy = pre_newy #pour prendre le haut des slopes / truc plat sans se bloquer sous un slope
                          touch_ground(world)
                          @vel_y = -@vel_y*@bouncyness

                          @vel_x *= @friction*@friction*@friction
                          @vel_y *= @friction*@friction*@friction


                          end

                        elsif  world.getzone_direct(xx,yy).Kind == 2  then
                            #gauche montant
                          pre_newy = (yy+1)*world.sq - @hitbox.get_surface_offset_y() - (world.sq- @hitbox.difference_slope_y(xx,yy,world.sq,x,y))
                          if pre_newy < newy  then
                              newy = pre_newy #pour prendre le haut des slopes / truc plat sans se bloquer sous un slope
                          touch_ground(world)
                          @vel_y = -@vel_y*@bouncyness

                          @vel_x *= @friction*@friction*@friction
                          @vel_y *= @friction*@friction*@friction

                          end

                        end



                end


                 if  (world.getzone_direct(xx,yy).Kind == 1 or world.getzone_direct(xx,yy).Kind == 4 ) and check_collide_world(x,y,xx*world.sq,yy*world.sq,world.sq) then


                   if xx == ix and yy != fy and world.getzone_direct(xx+1,yy).Kind == 0 then
                      newx = (xx+1)*world.sq + @hitbox.get_surface_offset_x()
                      @vel_x = -@vel_x*@bouncyness

                  elsif xx == fx and yy != fy and world.getzone_direct(xx-1,yy).Kind == 0 then
                      newx = (xx)*world.sq - @hitbox.get_surface_offset_x() - 1
                      @vel_x = -@vel_x*@bouncyness



                  elsif yy == iy and world.getzone_direct(xx,yy+1).Kind == 0  then
                      pre_newy = (yy+1)*world.sq + @hitbox.get_surface_offset_y()
                      if pre_newy < newy or newy == y then
                              newy = pre_newy #pour prendre le haut des slopes / truc plat
                      end
                      @vel_y = -@vel_y*@bouncyness
                      @vel_x *= @friction



                   elsif yy == fy and world.getzone_direct(xx,yy-1).Kind == 0 then
                      pre_newy = (yy)*world.sq - @hitbox.get_surface_offset_y()
                      if pre_newy < newy or newy == y then
                              newy = pre_newy #pour prendre le haut des slopes / truc plat
                          end
                      touch_ground(world)
                      @vel_y = -@vel_y*@bouncyness
                      @vel_x *= @friction



                   elsif xx == fx -1 and yy == fy -1 then
                      touch_ground(world)
                      #on ne sait pas dans quel sens on va
                        if  (@x - x).abs > (@y - y).abs  then
                            if x < @x then
                                newx = (xx+1)*world.sq + @hitbox.get_surface_offset_x()
                            else
                                newx = (xx)*world.sq - @hitbox.get_surface_offset_x()
                            end
                            @vel_x = -@vel_x*@bouncyness
                            @vel_y *= @friction



                        else
                            if y > @y then
                                pre_newy = (yy)*world.sq - @hitbox.get_surface_offset_y()
                                if pre_newy < newy or newy == y then
                                    newy = pre_newy #pour prendre le haut des slopes / truc plat
                                end
                            else
                                pre_newy = (yy+1)*world.sq + @hitbox.get_surface_offset_y()

                                if pre_newy > newy or newy == y then
                                    newy = pre_newy #pour prendre le haut des slopes / truc plat
                                end

                            end
                            @vel_y = -@vel_y*@bouncyness
                            @vel_x *= @friction


                        end

                    end

                end



            end
        end

        teleport(world,newx,newy)

    end



end

class Effect < PhysEnt
	attr_accessor  :animation 
	def initialize(image,cd,anim,sq = 20)
		super()
		@facing = 1
		@images = image 
		@animation = anim # c'est le numero de l'image utilis�e
		@countdown = cd
		@max_cd = cd
		@sq = sq

	end
	
	def draw(dx,dy)
	
		siz = @images[@animation].size
		anim = Integer( siz*( @max_cd - @countdown).to_f/@max_cd.to_f)

		@images[@animation][anim].draw(Integer(@x - dx -@facing*@sq), Integer(@y - dy -@sq), 150,@facing,1,0xffffffff)
	end
	
	def mainloop(world)
		main_move(world)
		@countdown += -1
		if @countdown <= 0 or $particles == 0 then
			destroy(world)
		end
	end

end

class Actor < PhysEnt
    attr_accessor :hp  ,:maxhp  , :mana , :maxmana, :animation , :animation_countdown , :falling , :facing , :speed , :jump
    def initialize()
        super()
        @speed = 0.5
        @jump = 15
        @hp = 10
	@maxhp = 10
	@mana = 100
	@maxmana = 100
        @facing = 1
        @blink = 0


        @animation_countdown = 0 #force l'application d'une meme animation pendant en temps
        @animation = 0 # sert a connaitre l'animation utilisée

    end

    def touch_ground(world)

       # if @falling < -40 and @vel_y > 12  then
        #    addhp(world,Integer( 40 + Integer(@falling*1.5) ))
	#end

	#if  @falling <= 0 and $particles >= 2 then 
	#	 4.times do
	#		    ef = Effect.new($Effects_images,32,4,4)
	#		    ef.hitbox = RectangleBox.new(4,4)
	#		    ef.vel_x = @vel_x + ( 2 - rand(4))
	#		    ef.vel_y =  -@vel_y - rand(2) + 2
	#		    ef.teleport($game.world,@x ,@y + @hitbox.height/1.45)
	#	    end
	#end

        @falling = 3
	
    end

    def does_see(world,ent)

        ex = ent.x
        ey = ent.y

        cx = @x
        cy = @y

        continues = 1

        loop do

            dx = -cx + ex
            dy = -cy + ey

            ox = cx
            oy = cy

            if dx.to_i.abs < 41 and dy.to_i.abs < 41 then
                return true
            end

            if dx.abs > dy.abs then
                cx += (dx.abs/dx)*world.sq
            else
                cy += (dy.abs/dy)*world.sq
            end

            if world.getzone(cx,cy).Kind == 1  then
                if  continues <= 0 then
                    return false # on ne peut pas voir
                else #on tente un autre passage
                    cx = ox
                    cy = oy
                    continues += -1
                    if dx.abs <= dy.abs then
                        cx += (dx.abs/dx)*world.sq if dx != 0
                    else
                        cy += (dy.abs/dy)*world.sq if dy != 0
                    end
                end
            end


        end

    end
    
    def addmana(val)
	@mana += val
	if val > 0 and @mana >= @maxmana then
		@mana = @maxmana
	end 
	
	@mana = 0 if @mana < 0
	
    end

    def addhp(world,val)

        if val < 0 and @blink > 0 then
            return
        end

	
        @hp += val
	#if val > 0 and @hp >= @maxhp then
		#@hp = @maxhp
	#end
	
	@hp = 0 if @hp < 0
	
        if @hp <= 0 then
            destroy(world)
	    
	    
	    ef = Effect.new($Effects_images,32,1)
	    ef.hitbox = RectangleBox.new(30,40)
	    ef.vel_x = @vel_x
	    ef.vel_y = @vel_y
	    ef.teleport(world,@x,@y)

		if  $particles >= 1 then
		    4.times do
			    ef = Effect.new($Effects_images,24,3)
			    ef.hitbox = RectangleBox.new(18,18)
			    ef.vel_x = @vel_x
			    ef.vel_y = @vel_y
			    ef.teleport(world,@x,@y)
			    ef.friction = 0.97
			    
			    ef.vel_x += (50 - rand(100)).to_f / 5
			    ef.vel_y += (50 - rand(100)).to_f / 5
		   end
	       end
	    
	    
        end

        if  val < 0 then
		
	   if  $particles >= 1 then
	     4.times do

		    ef = Effect.new($Effects_images,24,3)
		    ef.hitbox = RectangleBox.new(18,18)
		    ef.vel_x = @vel_x
		    ef.vel_y = @vel_y
		    ef.teleport(world,@x,@y)
		    ef.friction = 0.97
		    
		    ef.vel_x += (50 - rand(100)).to_f / 5
		    ef.vel_y += (50 - rand(100)).to_f / 5
	     end
	    end
		
            @blink = 20
        end

    end

    def run(coef)
        if  @falling > 0 then
            accx(@speed*coef)
	    if $countfps%13 == 2 and $particles >= 2 then 
		    ef = Effect.new($Effects_images,32,4,4)
		    ef.hitbox = RectangleBox.new(4,4)
		    ef.vel_x = @vel_x
		    ef.vel_y = @vel_y - 2
		    ef.teleport($game.world,@x ,@y + @hitbox.height/2)
	   end
    
        else
            accx(@speed*coef*0.6)
        end
    end

    def jump()
        if  @falling > 0 then
            accy(-@jump)
        end
    end

end









class RectangleBox
    attr_reader :width , :height
    def initialize(width,height)
        @width = width
        @height = height
        @type = 1 #rectangle
    end

    def check_collide(x,y,hb,wx,wy)

        if ((x - @width/2 <(wx + hb.width/2) )&&(x +  @width/2 >= wx -  hb.width/2 ) && (y +  @height/2 >= wy -  hb.height/2 ) &&( y - @height/2<(wy +hb.height/2)) ) then
            return true
         else
             return false
        end

    end
    
    def check_hit_melee(x,y,range,wx,wy)
	 if ((x - @width/2 <(wx + range) )&&(x +  @width/2 >= wx - range ) && (y +  @height/2 >= wy - range ) &&( y - @height/2<(wy +range)) ) then
            return true
         else
             return false
        end
    end

    def get_surface_offset_x()
        return Integer(@width/2)
    end

    def get_surface_offset_y()
        return Integer(@height/2)
    end

    def difference_slope_x(xx,yy,sq,x,y)
        dy = (y - (yy)*sq)
        return dy
    end

    def difference_slope_y(xx,yy,sq,x,y)
        dx = (x - (xx)*sq)
        return dx
    end

    def check_collide_world(x,y,wx,wy,sq)

         if ((x - @width/2 <(wx +sq ) )&&(x +  @width/2 >= wx ) && (y +  @height/2 >= wy ) &&( y - @height/2<(wy +sq)) ) then
            return true
         else
             return false
        end

    end


    def check_collide_world_slope(x,y,wx,wy,sq,kind)

        if kind == 2 then
         if ((x - @width/2 <(wx +sq ) )&&(x +  @width/2 >= wx ) && (y +  @height/2 >= wy + difference_slope_y(Integer(x/sq),Integer(y/sq),sq,x,y) ) &&( y - @height/2<(wy +sq)) ) then
            return true
         else
             return false
         end
        end

        if kind == 3 then
         if ((x - @width/2 <(wx +sq ) )&&(x +  @width/2 >= wx ) && (y +  @height/2 >= wy + sq  - difference_slope_y(Integer(x/sq),Integer(y/sq),sq,x,y) ) &&( y - @height/2<(wy +sq)) ) then
            return true
         else
             return false
         end
        end

    end

end




class Zone
  attr_accessor :Entities , :Image , :Kind , :x , :y

  def initialize(x,y)
    @Entities = Array.new() # table
    @Image =  Array[-1,0]
    @Kind = 0
  end

  def add(obj)
    @Entities.push(obj)
  end

  def remove(obj)
    @Entities.delete(obj)
  end

  def kind_01(val)

       return 1 if val == 2
       return 1 if val == 3
       return 0 if val == 0
       return 1 if val == 1
       return 1 if val == 4
       return 1 if val == 5

       return 0

  end

  def kind_slope(val)

      return 0 if val == 2
      return 0 if val == 3
      return 0 if val == 0
      return 1 if val == 1
      return 1 if val == 4
      return 1 if val == 5

      return 0

  end



  def get_type(world,x,y)

    me = @Kind

    left_mid = world.getzone_direct(x-1,y).Kind
    left_up = world.getzone_direct(x-1,y-1).Kind
    left_down = world.getzone_direct(x-1,y+1).Kind

    right_mid = world.getzone_direct(x+1,y).Kind
    right_up = world.getzone_direct(x+1,y-1).Kind
    right_down = world.getzone_direct(x+1,y+1).Kind

    up = world.getzone_direct(x,y-1).Kind
    down = world.getzone_direct(x,y+1).Kind

    if kind_slope(me) == 0 and kind_slope(left_up) == 0 and kind_slope(right_up) != 1  and kind_slope(right_mid) == 0  and kind_slope(left_mid )== 1  and kind_slope(up )== 0 and kind_slope(down )==1  and kind_slope(left_down )== 1 and down != 5 then
        @Kind = 2
        return
    end

    if kind_slope(me )== 0 and kind_slope(right_up) == 0  and kind_slope(left_up) != 1  and kind_slope(left_mid )== 0  and kind_slope(right_mid) == 1  and kind_slope(up) == 0 and kind_slope(down )==1  and kind_slope(right_down )== 1 and down != 5 then
        @Kind = 3
        return
    end

  end

  def get_image(ims,world,x,y)


    if @Image[0] != -1 then
        return
    end

    if @Kind == 2 then
        @Image[0] = 14
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if @Kind == 3 then
        @Image[0] = 13
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if @Kind == 4 then
        @Image[0] = 23
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if @Kind == 5 then
        @Image[0] = 24
        @Image[1] = rand(ims[@Image[0]].size)
	@Kind = 1
        return
    end


    me = @Kind

    left_mid = kind_01(world.getzone_direct(x-1,y).Kind)
    left_up = kind_01(world.getzone_direct(x-1,y-1).Kind)
    left_down = kind_01(world.getzone_direct(x-1,y+1).Kind)

    right_mid = kind_01(world.getzone_direct(x+1,y).Kind)
    right_up = kind_01(world.getzone_direct(x+1,y-1).Kind)
    right_down = kind_01(world.getzone_direct(x+1,y+1).Kind)

    up = kind_01(world.getzone_direct(x,y-1).Kind)
    down = kind_01(world.getzone_direct(x,y+1).Kind)

    down2 =  kind_01(world.getzone_direct(x,y+2).Kind)


    if me == 1  and right_mid == 0  and up == 0 and down ==0 and left_mid == 0  then
        @Image[0] = 9
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1 and right_mid == 1 and up == 0 and down == 0 and left_mid == 0  then
        @Image[0] = 7
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1 and left_mid == 1 and up == 0 and down == 0 and right_mid == 0   then
        @Image[0] = 8
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1  and right_mid == 0 and left_mid == 0 and down == 1 and up == 0 then
        @Image[0] = 10
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1  and right_mid == 0 and left_mid == 0 and down == 0 and up == 1 then
        @Image[0] = 11
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1 and left_mid == 0 and left_up == 0 and up == 0 then
        @Image[0] = 4
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1 and right_mid == 0 and right_up == 0 and up == 0  then
        @Image[0] = 3
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if down2 == 0  and  me == 1 and left_mid == 0 and left_down == 0 and down == 0 then
        @Image[0] = 21  # juste pour faire beau pas une vraie slope
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if down2 == 0  and me == 1 and right_mid == 0 and right_down == 0 and down == 0 then
        @Image[0] = 22  # juste pour faire beau pas une vraie slope
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1 and left_mid == 0 and left_down == 0 and down == 0 then
        @Image[0] = 5
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1 and right_mid == 0 and right_down == 0 and down == 0 then
        @Image[0] = 6
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 0 and right_mid == 1 and right_down == 1 and right_up == 1 and down == 1 and up == 1 and left_mid == 1 and left_down == 1 and left_up == 1 then
        @Image[0] = 12
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end


     if me == 1 and up == 0 and down == 0 then
        @Image[0] = 17
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end


    if me == 1 and up == 0 and down == 1 then
        @Image[0] = 15
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1 and up == 1 and down ==0 then
        @Image[0] = 16
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1 and left_mid == 0 and right_mid ==0 then
        @Image[0] = 20
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1 and left_mid == 1 and right_mid ==0 then
        @Image[0] = 18
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end

    if me == 1 and left_mid == 0 and right_mid ==1 then
        @Image[0] = 19
        @Image[1] = rand(ims[@Image[0]].size)
        return
    end



    if me == 0 then
        @Image[0] = 1
        @Image[1] = rand(ims[@Image[0]].size)

    else
        @Image[0] = 2
        @Image[1] = rand(ims[@Image[0]].size)
    end

  end



end

class World
  attr_accessor :x , :y ,:sq , :asteroids,:projectiles,:player , :gravity , :max_speed_fall , :Zones , :player ,  :Ents , :full_calculus

  def initialize(sx,sy)

    @x = sx
    @y = sy
    @sq = 40 # taille d'un carré
    @gravity = 0.8
    @max_speed_fall = 30

    @Ents = Array.new() #utilisé qu'en full_calculus

    @full_calculus = false# si on calcule toute la map
    # fait beaucoup plus ramer mais permet de faire buger tout les monstres de la map.
    # bien pour les map ecosystèmes

    # si false seuls les monstres presents à l'écran bougent




    @player = Player.new()



    @Zones = Array.new(@x){[]}

    (0..@x-1).each do |x|
      (0..@y-1).each do |y|

      @Zones[x][y] = Zone.new(x,y)

      end
    end


  end


  def remove(obj)
    @Zones[Integer(obj.x/@sq)][Integer(obj.y/@sq)].removeA(obj)
  end

  def append(obj)
    @Zones[Integer(obj.x/@sq)][Integer(obj.y/@sq)].addA(obj)
  end


  def dig_small_hole(x,y)

      getzone(x,y).Kind = 0 if getzone(x,y).Kind != 4
      getzone(x+40,y).Kind = 0 if getzone(x+40,y).Kind != 4
      getzone(x-40,y).Kind = 0 if getzone(x-40,y).Kind != 4
      getzone(x+80,y).Kind = 0 if getzone(x+80,y).Kind != 4
      getzone(x-80,y).Kind = 0 if getzone(x-80,y).Kind != 4

      getzone(x,y+40).Kind = 0 if getzone(x,y+40).Kind != 4
      getzone(x+40,y+40).Kind = 0 if getzone(x+40,y+40).Kind != 4
      getzone(x-40,y+40).Kind = 0 if getzone(x-40,y+40).Kind != 4

      getzone(x,y-40).Kind = 0 if getzone(x,y-40).Kind != 4
      getzone(x+40,y-40).Kind = 0 if getzone(x+40,y-40).Kind != 4
      getzone(x-40,y-40).Kind = 0 if getzone(x-40,y-40).Kind  != 4




      sx = gdx(x-120)
      sy = gdy(y-120)

      fx = gdx(x+120)
      fy = gdy(y+120)


      (sx..fx).each do |xx|
         (sy..fy).each do |yy|
	     z = getzone_direct(xx,yy)
		 # on endommage les monstres
		 z.Entities.each do |ent|
			 if  ent.class != Player and ent.class != Boulder and ent.class != Effect and ent.class != Projectile and ent.class != Continue and ent.class != Bomb and ent.class != Dynamite and ent.class != Hearth then
				ent.addhp(self,-50) 
			end
		end
		 
		 
		 
            
            z.Image[0] = -1 # comme ça on change les images au redraw
            if z.Kind == 2 or z.Kind == 3 then
                z.Kind = 0
            end
            z.get_type(self,xx,yy) if z.Kind != 4

         end
      end

  end

  def gddy(zx)

    if zx < 0 then
        zx = 0

    elsif zx >= @y*@sq then
        zx = @y*@sq - @sq
    end

    return zx

  end


  def gddx(zx)

    if zx < 0 then
        zx = 0

    elsif zx >= @x*@sq then
        zx = @x*@sq - @sq
    end

    return zx

  end

  def gd(x)
      return Integer(x/@sq)
  end

  def gdx(x)

    zx = gd(x)

    if zx < 0 then
        zx = 0

    elsif zx >= @x then
        zx = @x - 1
    end

    return zx

  end

  def gdy(x)

    zy = gd(x)

    if zy < 0 then
        zy = 0

    elsif zy >= @y then
        zy = @y - 1
    end

    return zy

  end

  def getzone(x,y)

    zx = gdx(x)
    zy = gdy(y)

    return @Zones[zx][zy]

  end

  def getzone_direct(x,y)

    nx = x
    ny = y

    if x < 0
        nx = 0
    end

    if y < 0
        ny = 0
    end

    if x >= @x
        nx = @x - 1
    end

    if y >= @y
        ny = @y - 1
    end

    return @Zones[nx][ny]
  end


end


#Thomas Kurzanski 2010
#kurzanski.thomas@gmail.com

puts "Loading... Please wait."

require 'gosu'
require 'World'
require 'Game'
require 'Entities'
require 'RandomMap'
require 'Monsters'


class ControlMenu
	attr_accessor :cursor , :attack1 , :attack2 , :down , :jump , :left , :right,:font
	def initialize(sx,sy)
		@cursor = 0 
		
		@attack1 = 57
		@attack2 = 56
		@down = 208
		@jump = 200
		@left = 203
		@right = 205
		
		@font = font
		@sx = sx
		@sy = sy
	end
	
	def button_pressed(id)
		return if Gosu::Button::KbReturn == id or id == Gosu::Button::KbEscape
		if @cursor == 0 then
			@attack1 = id
		elsif @cursor == 1 then
			@attack2 = id
		elsif @cursor == 2 then
			@down = id
		elsif @cursor == 3 then
			@jump = id
		elsif @cursor == 4 then
			@left = id
		elsif @cursor == 5 then
			@right = id
		end
		
		@cursor = (@cursor + 1)%6
	
	end

	def draw()
		if @cursor == 0 then
			draw_text("Primary attack")
		elsif @cursor == 1 then
			draw_text("Secondary Attack")
		elsif @cursor == 2 then
			draw_text("Down")
		elsif @cursor == 3 then
			draw_text("Jump")
		elsif @cursor == 4 then
			draw_text("Left")
		elsif @cursor == 5 then
			draw_text("Right")
		end
	end
	
	def draw_text(text)
		@font.draw( "PRESS THE KEY FOR : " , @sx/2 - 150,  @sy/2, 255, 1.0, 1.0, 0xffff0000)
		@font.draw(  text, @sx/2 - 150,  @sy/2 + 40, 255, 1.0, 1.0, 0xffffff00)
	end

	
end

class Menu
	attr_accessor :cursor , :Texts
  def initialize(texts,font,sx,sy,title)
	@sx = sx
	@sy = sy
	@cursor = 0
	@Texts = texts # array
	
	@title = title
	
	@font = font
	
   end
 
  def down()
	@cursor = (@cursor + 1)%@Texts.size
  end
  
  def up()
	@cursor = (@cursor - 1)%@Texts.size
  end

  def draw(deb = 0)
	  
	  
	incr = 0
	s = @sx/2
		  
	$window.draw_quad(s - 150, 120, 0x99000000, s + 150, 120,  0x99000000, s - 150, 150 + @Texts.length*25, 0x99000000,  s + 150, 150 + @Texts.length*25, 0x99000000, 255) 
	
	
	@Texts.each do |t|
		if @cursor == incr then
			@font.draw( t[deb,t.length] + " <-", s - 100, 150 +  incr*25, 255, 1.0, 1.0, 0xffffffff)
		else
			@font.draw( t[deb,t.length] , s - 100, 150 +  incr*25, 255, 1.0, 1.0, 0xffffff00)
		end
		incr += 1
	end
	
	@font.draw( @title, s - 150,  120, 255, 1.0, 1.0, 0xffff0000)
   end

	
	
end

class TheWindow < Gosu::Window
  attr_accessor :text , :pause

  def initialize

    @sx = 500
    @sy = 500
    @fs = false
    @sound = true
    @tampon = 0
    $particles = 1
    
    @ControlMenu = ControlMenu.new(@sx, @sy)
    
    get_config()


    super(@sx ,@sy,@fs, update_interval = 17)
    
    @font = Gosu::Font.new(self, Gosu::default_font_name, 20)
    @fontmenu = Gosu::Font.new(self, "Lucida Console", 26)
    @fontmini = Gosu::Font.new(self, "Lucida Console", 10)
    @fonttext = Gosu::Font.new(self, "Lucida Console", 20)
    
    @msgMidle = ""
    @msgTimer = 0
    
    
    @ControlMenu.font = @fontmenu 
    
    @MenuCursor = 0
    @MainMenu = Menu.new(["New Game","Controls","Quit" ], @fontmenu ,@sx, @sy,"Main Menu")
    @MapList = Array.new
     load_map_list()
    @MapMenu = Menu.new(@MapList, @fontmenu ,@sx, @sy,"Load Map") 
    @MapDesc = "No description"
    
    @map_tile = 0

    


    $Tiles_images = Array.new
    
    2.times do
	$Tiles_images.push(Array.new)
    end

    (0..24).each do |x|
	 
	$Tiles_images[0].push(Gosu::Image.load_tiles(self, "media/tiles/terre/"+ x.to_s() +".png",40,40,true))
	$Tiles_images[1].push(Gosu::Image.load_tiles(self, "media/tiles/terbix/"+ x.to_s() +".png",40,40,true))
    end


    @hearth = Gosu::Image.new(self, "media/hud/hearth.png", false)
    @hearth1 = Gosu::Image.new(self, "media/hud/hearth1.png", false)

    @bomb = Gosu::Image.new(self, "media/hud/dynamite.png", false)
    
    @menu_tile = Gosu::Image.new(self, "media/menu/blanc.png", false)
    @menu_tache = Gosu::Image.new(self, "media/menu/tache.png", false)
    @menu_vous = Gosu::Image.new(self, "media/menu/vous.png", false)
    @menu_title = Gosu::Image.new(self, "media/menu/title.png", false)
    
    $springs_images = Array.new
    $springs_images.push(Gosu::Image.load_tiles(self, "media/springs/1.png",40,40, false))
    $springs_images.push(Gosu::Image.load_tiles(self, "media/springs/2.png",40,40, false))
   
    $boulders_images = Array.new
    $boulders_images.push(Gosu::Image.load_tiles(self, "media/boulders/rock.png",40,40, false))
    
    $Effects_images = Array.new
    $Effects_images.push(Gosu::Image.load_tiles(self, "media/effects/expl1.png",40,40, false))
    $Effects_images.push(Gosu::Image.load_tiles(self, "media/effects/boom.png",40,40, false))
    $Effects_images.push(Gosu::Image.load_tiles(self, "media/effects/expl2.png",40,40, false))
    $Effects_images.push(Gosu::Image.load_tiles(self, "media/effects/blood.png",40,40, false))
    $Effects_images.push(Gosu::Image.load_tiles(self, "media/effects/dust.png",7,7, false))


    $Player_images = Array.new
    $Player_images.push(Gosu::Image.new(self, "media/player/idle.png", false))
    $Player_images.push(Gosu::Image.new(self, "media/player/jump.png", false))
    $Player_images.push(Gosu::Image.new(self, "media/player/move1.png", false))
    $Player_images.push(Gosu::Image.new(self, "media/player/move2.png", false))
    $Player_images.push(Gosu::Image.new(self, "media/player/move3.png", false))
    $Player_images.push(Gosu::Image.new(self, "media/player/attack1.png", false))
    $Player_images.push(Gosu::Image.new(self, "media/player/attack2.png", false))
    $Player_images.push(Gosu::Image.new(self, "media/player/attack3.png", false))
    $Player_images.push(Gosu::Image.new(self, "media/player/attack4.png", false))
    $Player_images.push(Gosu::Image.new(self, "media/player/idle2.png", false))

    $Troll_images = Array.new
    $Troll_images.push(Gosu::Image.new(self, "media/monsters/troll/idle.png", false))
    $Troll_images.push(Gosu::Image.new(self, "media/monsters/troll/jump.png", false))
    $Troll_images.push(Gosu::Image.new(self, "media/monsters/troll/attack.png", false))
    $Troll_images.push(Gosu::Image.new(self, "media/monsters/troll/move.png", false))
    $Troll_images.push(Gosu::Image.new(self, "media/monsters/troll/move2.png", false))
    $Troll_images.push(Gosu::Image.new(self, "media/monsters/troll/move3.png", false))

    $Lizard_images= Array.new
    $Lizard_images.push(Gosu::Image.new(self, "media/monsters/lizard/idle.png", false))
    $Lizard_images.push(Gosu::Image.new(self, "media/monsters/lizard/jump.png", false))
    $Lizard_images.push(Gosu::Image.new(self, "media/monsters/lizard/attack.png", false))
    $Lizard_images.push(Gosu::Image.new(self, "media/monsters/lizard/move1.png", false))
    $Lizard_images.push(Gosu::Image.new(self, "media/monsters/lizard/move2.png", false))
    $Lizard_images.push(Gosu::Image.new(self, "media/monsters/lizard/move3.png", false))

    $Lermitte_images = Array.new
    $Lermitte_images.push(Gosu::Image.new(self, "media/monsters/lermitte/idle.png", false))
    $Lermitte_images.push(Gosu::Image.new(self, "media/monsters/lermitte/jump.png", false))
    $Lermitte_images.push(Gosu::Image.new(self, "media/monsters/lermitte/attack.png", false))
    $Lermitte_images.push(Gosu::Image.new(self, "media/monsters/lermitte/attack2.png", false))
    $Lermitte_images.push(Gosu::Image.new(self, "media/monsters/lermitte/move1.png", false))
    $Lermitte_images.push(Gosu::Image.new(self, "media/monsters/lermitte/move2.png", false))
    $Lermitte_images.push(Gosu::Image.new(self, "media/monsters/lermitte/move3.png", false))
    
    $Lermitte2_images = Array.new
    $Lermitte2_images.push(Gosu::Image.new(self, "media/monsters/superlermitte/idle.png", false))
    $Lermitte2_images.push(Gosu::Image.new(self, "media/monsters/superlermitte/jump.png", false))
    $Lermitte2_images.push(Gosu::Image.new(self, "media/monsters/superlermitte/attack.png", false))
    $Lermitte2_images.push(Gosu::Image.new(self, "media/monsters/superlermitte/move1.png", false))
    $Lermitte2_images.push(Gosu::Image.new(self, "media/monsters/superlermitte/move2.png", false))
    $Lermitte2_images.push(Gosu::Image.new(self, "media/monsters/superlermitte/move3.png", false))


    $Bat_images= Array.new
    $Bat_images.push(Gosu::Image.new(self, "media/monsters/bat/idle.png", false))
    $Bat_images.push(Gosu::Image.new(self, "media/monsters/bat/jump.png", false))
    $Bat_images.push(Gosu::Image.new(self, "media/monsters/bat/attack.png", false))
    $Bat_images.push(Gosu::Image.new(self, "media/monsters/bat/move.png", false))

    $Catroll_images= Array.new
    $Catroll_images.push(Gosu::Image.new(self, "media/monsters/catroll/idle.png", false))
    $Catroll_images.push(Gosu::Image.new(self, "media/monsters/catroll/jump.png", false))
    $Catroll_images.push(Gosu::Image.new(self, "media/monsters/catroll/attack.png", false))
    $Catroll_images.push(Gosu::Image.new(self, "media/monsters/catroll/move.png", false))
    $Catroll_images.push(Gosu::Image.new(self, "media/monsters/catroll/move2.png", false))
    $Catroll_images.push(Gosu::Image.new(self, "media/monsters/catroll/move3.png", false))

    $Projectiles_images = Array.new
    $Projectiles_images.push(Gosu::Image.load_tiles(self, "media/projectiles/javelin.png",30,30,true))
    $Projectiles_images.push(Gosu::Image.load_tiles(self, "media/projectiles/javelin2.png",30,30,true))
    $Projectiles_images.push(Gosu::Image.load_tiles(self, "media/projectiles/javelin3.png",30,30,true))
    $Projectiles_images.push(Gosu::Image.load_tiles(self, "media/projectiles/javelin4.png",30,30,true))
    $Projectiles_images.push(Gosu::Image.load_tiles(self, "media/projectiles/stone.png",30,30,true))
    $Projectiles_images.push(Gosu::Image.load_tiles(self, "media/projectiles/dynamite.png",30,30,true))
    $Projectiles_images.push(Gosu::Image.load_tiles(self, "media/projectiles/spit.png",30,30,true))

    $Item_images = Array.new
    $Item_images.push(Gosu::Image.new(self, "media/powerups/save.png", false))
    $Item_images.push(Gosu::Image.new(self, "media/powerups/hearth.png", false))
    $Item_images.push(Gosu::Image.new(self, "media/powerups/dynamite.png", false))
    $Item_images.push(Gosu::Image.new(self, "media/powerups/exit.png", false))
    
    

   

    ###
    
    @mode = 0 # 0 = menu et 1 = game

    $game = Game.new()
    @valid_game = false # si on peut faire echap pour revenir a la partie en cours


    $countfps = 0
    @fps=640
    @temps = Time.now.sec
    
   #  rd =  RandomMap.new(300,70)
     #rd.create()
    # rd.write_file()


  end
  
  
  def load_map_list()
	@MapList = Array.new
	Dir.glob("simplemaps/*.txt") {|filename|
		@MapList.push(filename )
	}
  end


  def load_map_description(text)
	    t= IO.readlines(text)
	    
	    t.each_index{|f| # on cherche le debut de la map
	    
	    if t[f][0, 12] == ":description" then
		    return  t[f][13,t[f].length]
	    end
	    
	    }
	    
	    return "No description"
	  
  end

  def load_simple_map(text)

	
    t= IO.readlines(text)
    line = 0
    
    new_max_speed_fall =  -1
    new_gravity = -1
    new_speed = -1
    new_jump = -1
    new_spring = -1
    
    t.each_index{|f| 
    
    if t[f][0, 10] == ":death_msg" then
	    $game.death_msg = t[f][11, t[f].length]
    end
    
    if t[f][0, 5] == ":tile" then
	    @map_tile = Integer(t[f][6, t[f].length])
    end

    
    if t[f][0, 8] == ":win_msg" then
	    $game.win_msg = t[f][9, t[f].length]
    end
    
    if t[f][0, 10] == ":start_msg" then
	    display_msg_midle(t[f][11, t[f].length],150)
    end
    
    if t[f][0, 15] == ":max_speed_fall" then
	    new_max_speed_fall = Integer(t[f][16, t[f].length])
    end
    
    if t[f][0, 8] == ":gravity" then
	    new_gravity =  Float(t[f][9, t[f].length])
    end
    
    if t[f][0, 6] == ":speed" then
	    new_speed =  Float(t[f][7, t[f].length])
    end
    
    if t[f][0, 5] == ":jump" then
	    new_jump =  Float(t[f][6, t[f].length])
    end
    
    if t[f][0, 7] == ":spring" then
	    new_spring =  Float(t[f][8, t[f].length])
    end
    
    if t[f][0, 4] == ":map" then # on cherche le debut de la map
	    t = t[f+1,t.length]
	    break
    end
    
    }

    $game.world = World.new(t[0].size(),t.size())

    $game.player = $game.world.player
    $game.player.images = $Player_images
    $game.player.projectile_images = $Projectiles_images
    
    $game.world.max_speed_fall = new_max_speed_fall if new_max_speed_fall >= 0
    $game.world.gravity = new_gravity if new_gravity >= 0
    $game.player.speed = new_speed if new_speed >= 0
    $game.player.jump = new_jump if new_jump >= 0
    $game.spring = new_spring if new_spring >=0
    

    t.each_index{|f|

        row = 0
        t[f].size.times do
		
            $game.create_from_char(t[f][row],row,line)

            row += 1

        end

        line += 1

    }

    (0..$game.world.x - 1).each do |x|
         (0..$game.world.y - 1).each do |y|
             zone = $game.world.getzone_direct(x,y)
             if zone.Image[0] == -1 then
                 zone.get_type( $game.world,x,y)
             end

         end

     end

  end

  def write_config()
	  File.open("config.txt", 'r+') {|f| 
	  
	  
	  f.write("resolution_x " + String(@sx) + "\n")
	  f.write("resolution_y " + String(@sy)+ "\n")
	  f.write("buffer " + String(Integer(@tampon))+ "\n")
	  f.write("fullscreen " + String(@fs ? 1 : 0 )+ "\n")
	  f.write("particles " + String($particles  )+ "\n")
	  f.write("sound " + String(@sound ? 1 : 0)+ "\n\n")
	  
	  
	  f.write("jump " + String(@ControlMenu.jump)+ "\n") 
	  f.write("down " + String(@ControlMenu.down)+ "\n") 
	  f.write("left " + String(@ControlMenu.left)+ "\n") 
	  f.write("right " + String(@ControlMenu.right)+ "\n") 
	  f.write("attack1 " + String(@ControlMenu.attack1)+ "\n") 
	  f.write("attack2 " + String(@ControlMenu.attack2)+ "\n") 
	  
	  }

  end

  def get_config()

      t = IO.readlines("config.txt")
      t.each_index{|f|

       tbl = t[f].split(" ")

       if tbl[0] == "resolution_x" then
         @sx = Integer(tbl[1])
       end

       if tbl[0] == "resolution_y" then
         @sy = Integer(tbl[1])
	end
 
	if tbl[0] == "jump" then
         @ControlMenu.jump = Integer(tbl[1])
	end
	if tbl[0] == "down" then
         @ControlMenu.down = Integer(tbl[1])
	end
	if tbl[0] == "attack1" then
         @ControlMenu.attack1 = Integer(tbl[1])
	end
	if tbl[0] == "attack2" then
         @ControlMenu.attack2 = Integer(tbl[1])
	end
	if tbl[0] == "left" then
         @ControlMenu.left = Integer(tbl[1])
	end
	if tbl[0] == "right" then
         @ControlMenu.right = Integer(tbl[1])
	end

        if tbl[0] == "sound" then
         if  Integer(tbl[1]) == 0 then
            @sound = false
           else
            @sound = true
          end

        end

       if tbl[0] == "fullscreen" then
            if  Integer(tbl[1]) == 0 then
                @fs = false
            else
                @fs = true
            end

      end
      
      if tbl[0] == "particles" then
		$particles = Integer(tbl[1])
	end
	
      
       if tbl[0] == "buffer" then
		@tampon = Integer(tbl[1])
      end


      }

    end


  def draw_entities()

      tampon = @tampon

      dx = Integer($game.player.x - @sx/2)
      dy = Integer($game.player.y - @sy/2)

      sx = $game.world.gdx($game.player.x - @sx/2 - tampon)
      sy = $game.world.gdy($game.player.y - @sy/2 - tampon)

      fx = $game.world.gdx($game.player.x + @sx/2 + tampon)
      fy = $game.world.gdy($game.player.y + @sy/2 + tampon)


      (sx..fx).each do |x|
         (sy..fy).each do |y|

             zone = $game.world.getzone_direct(x,y)

             zone.Entities.each do |ent|
                 ent.draw(dx,dy)
             end




         end

     end


  end

  def draw_world()

      tampon = @tampon

      dx = Integer($game.player.x - @sx/2)
      dy = Integer($game.player.y - @sy/2)

      sx = $game.world.gdx($game.player.x - @sx/2 - tampon)
      sy = $game.world.gdy($game.player.y - @sy/2 - tampon)

      fx = $game.world.gdx($game.player.x + @sx/2 + tampon)
      fy = $game.world.gdy($game.player.y + @sy/2 + tampon)


      (sx..fx).each do |x|
         (sy..fy).each do |y|

             zone = $game.world.getzone_direct(x,y)

             if zone.Image[0] == -1 then
                 zone.get_image( $Tiles_images[@map_tile],$game.world,x,y)
             end
             $Tiles_images[@map_tile][zone.Image[0]][zone.Image[1]].draw(x * $game.world.sq - dx, y * $game.world.sq - dy , 1,1,1,0xffffffff)

         end

     end


  end



  def draw_hud()



        hearths = Integer(($game.player.hp / 20).floor)

        h = 0

        hearths.times do
	    @hearth.draw(10 +h*25, @sy -25, 255, 1.0, 1.0, 0xffffff00)
            h += 1
        end

        if $game.player.hp % 20 >= 10 then
            @hearth1.draw(10 +h*25, @sy -25, 255, 1.0, 1.0, 0xffffff00)
        end
       
        #draw_quad(10, @sy - 30, 0x99000000, 160, @sy - 30,  0x99000000, 10, @sy - 10, 0x99000000,  160, @sy - 10, 0x99000000, 255) 
	#draw_quad(10, @sy - 30 - 25, 0x99000000, 160, @sy - 30 - 25,  0x99000000, 10, @sy - 10 - 25, 0x99000000,  160, @sy - 10 - 25, 0x99000000, 255) 

	#ratiohp = Float($game.player.hp)/Float($game.player.maxhp)
	#ratiomana = Float($game.player.mana)/Float($game.player.maxmana)
	
	#draw_quad(12, @sy - 30 +2, 0xffff0000, 158*ratiohp, @sy - 30  +2,  0xffff4444, 12, @sy - 10 - 2, 0xffff0000,  158*ratiohp, @sy - 10  - 2, 0xffff4444, 255)  if  ratiohp >= 0.01
	#draw_quad(12, @sy - 30 - 25  +2, 0xff0000ff, 158*ratiomana, @sy - 30 - 25  +2,  0xff4444ff, 12, @sy - 10 - 25  - 2, 0xff0000ff,  158*ratiomana, @sy - 10 - 25  - 2, 0xff4444ff, 255) if  ratiomana >= 0.01

	#@fontmini.draw("#{$game.player.hp}/#{$game.player.maxhp} ", 20, @sy - 25 , 255, 1.0, 1.0, 0xffffffff) 
	#@fontmini.draw("#{$game.player.mana}/#{$game.player.maxmana} ", 20, @sy - 25  - 25, 255, 1.0, 1.0, 0xffffffff) 

        h = 0
        $game.player.bombs.times do
            @bomb.draw(10 +h*8, @sy -50, 255, 1.0, 1.0, 0xffffff00)
            h += 1
        end



        #@font.draw("falling : #{$game.world.player.falling}", 10, 10, 254, 1.0, 1.0, 0xffffaa22)

       # @font.draw("vy : #{$game.world.player.vel_y }", 10, 30, 254, 1.0, 1.0, 0xffffaa22)
       # @font.draw("vx : #{$game.world.player.vel_x }", 10, 50, 254, 1.0, 1.0, 0xffffaa22)


        #@font.draw("Entities : #{$game.world.Ents.size }", 10, 50, 254, 1.0, 1.0, 0xffffaa22)



	if @fps <  58  then
		@font.draw("FPS: #{@fps} ", @sx -70, @sy -25, 255, 1.0, 1.0, 0xffffff00)
	end
	
	draw_msg_midle()

        #@font.draw("SCORE : #{$game.world.player.points}", 10, @sy -25, 255, 1.0, 1.0, 0xffaaff22)


       # if @fps <  55  then
           # color = Gosu::Color.new(0xff000000)
          # color.red =255
            #color.green =0
           # color.blue =0
           # @font.draw("PERFORMANCE WARNING", Integer(@sx/2) - 100, Integer(@sy/2) + 100, 255, 1.0, 1.0, color)
       # end

    end

  def display_msg_midle(msg,time)
	  @msgMidle = msg
	  @msgTimer = time
  end
  
  def draw_msg_midle()
	  if @msgTimer > 0 then
		@msgTimer += -1
		@font.draw( @msgMidle, @sx/2 - @msgMidle.length*4, @sy/2 + 30, 255, 1.0, 1.0, 0xffffff00)
	  end
  end

  def game_loop()

      tampon = @tampon

      $countfps += 1

      if  @temps != Time.now.sec
            @temps = Time.now.sec
            @fps=$countfps
            $countfps =0
      end


      sx = $game.world.gdx($game.player.x - @sx/2 - tampon)
      sy = $game.world.gdy($game.player.y - @sy/2 - tampon)

      fx = $game.world.gdx($game.player.x + @sx/2 + tampon)
      fy = $game.world.gdy($game.player.y + @sy/2 + tampon)

      $game.mainloop(sx,sy,fx,fy)
      
      


    end

  def  restart()
	sx = $game.player.x_restart
        sy = $game.player.y_restart
        $game = Game.new()
        load_simple_map(@MapList[@MapMenu.cursor])
        $game.player.teleport($game.world,sx,sy)
        $game.player.images = $Player_images
        $game.player.projectile_images = $Projectiles_images
   end

  def draw_menus()
	  
	  xx = Integer((@sx / 80).ceil)
	  yy = Integer((@sy / 80).ceil)
           
	   
	  rr = ( Gosu::milliseconds()/75) %100*2
	  
	  if rr > 100 then
		  rr = 100*2 - rr
	  end
	  
	  col = Gosu::Color.new(255,rr + 100,rr+ 100,rr+ 100)
	  
	  (0..xx).each do |sx|
		  (0..yy).each do |sy|
			@menu_tile.draw(sx*80,sy*80 , 255, 1.0, 1.0, col)
		end
	  end
	
	  @menu_title.draw(@sx/2 - 200 ,25  , 255, 1.0, 1.0, col)
	  @menu_tache.draw(@sx - 500,@sy - 500 , 255, 1.0, 1.0, 0xffffffff)
	  @menu_vous.draw(@sx - 400 + rand(3) ,@sy - 400+ rand(3) , 255, 1.0, 1.0, col)
	  
	  
	  if @MenuCursor == 0 then
		@MainMenu.draw()
	  end
	  if @MenuCursor == 1 then
	 	@MapMenu.draw(11)
		@font.draw(@MapDesc, 50, @sy -90, 255, 1.0, 1.0, 0xffffff00)
		
	  end
	  if @MenuCursor == 2 then
		@ControlMenu.draw()
	  end
	
	@font.draw("V 0.31", 50, @sy -45, 255, 1.0, 1.0, 0xff000000)
	@font.draw("Press ESC to close menu", 50, @sy -25, 255, 1.0, 1.0, 0xff000000)
	  
  end
  
  def draw_dead()
	@fonttext.draw($game.death_msg, @sx/2 - 70, @sy/2 + 40, 255, 1.0, 1.0, 0xffff0000)
	@fonttext.draw("-Press Return", @sx/2 - 70, @sy/2 + 70, 255, 1.0, 1.0, 0xffffff00) if $countfps < 30
  end

  def draw_win()
	@fonttext.draw($game.win_msg, @sx/2 - 70, @sy/2 + 40, 255, 1.0, 1.0, 0xff00ff00)
	@fonttext.draw("-Press Return", @sx/2 - 70, @sy/2 + 70, 255, 1.0, 1.0, 0xffffff00) if $countfps < 30
  end

  def draw()
	if @mode == 1 then
		draw_world()
		draw_hud()
		draw_entities()
		
		
		draw_dead() if $game.player.statusp == 1
		
		draw_win() if $game.player.statusp == 2
	end
	if @mode == 0 then
		draw_menus()
	end


    end
    
   

  def game_update()
	  
    if button_down? @ControlMenu.left and not button_down?  @ControlMenu.down  then
      $game.player.go_left()
    end
    if button_down? @ControlMenu.right and not button_down?  @ControlMenu.down  then
      $game.player.go_right()
    end
    
    if button_down? @ControlMenu.left and  button_down?  @ControlMenu.down  then
      $game.player.go_left_b()
    end
    if button_down? @ControlMenu.right and  button_down?  @ControlMenu.down  then
      $game.player.go_right_b()
    end

    if button_down?  @ControlMenu.attack1 and not button_down?  @ControlMenu.down then
      $game.player.fire($game.world)
    end
    
    
      if button_down?  Gosu::Button::KbReturn then
	    if  $game.player.statusp == 1 then
		restart()
	     end
	      if  $game.player.statusp == 2 then
		end_level()
		end
	end


    if button_down?  @ControlMenu.attack1 and button_down?  @ControlMenu.down then
      $game.player.firesecondary($game.world)
    end

    if button_down?  @ControlMenu.attack2 then
      $game.player.fire_bomb($game.world)
    end
    
	  
  end
  
  def end_level()
	  @mode = 0
	  $game = Game.new()
	  @valid_game = false # si on peut faire echap pour revenir a la partie en cours
  end

  def update()

    if @mode == 1 then
	game_update()
	game_loop()
    end
  
    
  end
  
  def game_button(id)
    if id == @ControlMenu.jump
      $game.player.do_jump()
    end

    if id == Gosu::Button::KbEscape
      @mode = 0
    end
 
  end
  
  def menu_button(id)
	  
    if @MenuCursor == 2 and @mode == 0 then
	     @ControlMenu.button_pressed(id)
    end
	  
    if id == Gosu::Button::KbUp
	if @MenuCursor == 0 then
		@MainMenu.up()
	end
	if @MenuCursor == 1 then
		@MapMenu.up()
		if @MapList.length > 0 then
			@MapDesc = load_map_description(@MapList[@MapMenu.cursor])
		end
	end
    end
    if id == Gosu::Button::KbDown
	if @MenuCursor == 0 then
		@MainMenu.down()
	end
	if @MenuCursor == 1 then
		@MapMenu.down()
		if @MapList.length > 0 then
			@MapDesc =  load_map_description(@MapList[@MapMenu.cursor])
		end
	end
   end

   if id == Gosu::Button::KbReturn
	if @MenuCursor == 1 then
		#@font.draw("MAP IS LOADING", @sx /2, @sy/2, 255, 1.0, 1.0, 0xffffff00)
		load_simple_map(@MapList[@MapMenu.cursor])
		@mode = 1
		@valid_game = true
	end
	if @MenuCursor == 0 then
		if @MainMenu.cursor == 0 then
			@MenuCursor = 1
			@MapDesc = load_map_description(@MapList[@MapMenu.cursor])
		end
		if @MainMenu.cursor == 1 then
			@MenuCursor = 2
		end
		if @MainMenu.cursor == 2 then
			close
		end
	end
    end  

    if id == Gosu::Button::KbEscape
	    if @valid_game and @MenuCursor == 0 then
		    @mode = 1
	    else
		    if @MenuCursor == 2 then
			    write_config() # on sort du menu de config control
		    end
		    @MenuCursor = 0
	    end
    end
   
  end

  def button_down(id)
     if @mode == 1 then
	game_button(id)
     elsif @mode == 0 then
	menu_button(id)
     end

  end


end


puts "..."
$window = TheWindow.new()
puts "Loading complete."
$window.show()



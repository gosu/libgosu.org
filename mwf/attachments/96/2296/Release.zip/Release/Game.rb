class Game
  attr_accessor :world , :player , :death_msg , :win_msg ,:spring
  def initialize()

      @world = World.new(1,1)

      @player = @world.player
      
      @death_msg = "You are dead"
      @win_msg = "Level completed"
      @spring = 30
      

  end
  
  def create_from_char(char,row,line)
	   z = @world.getzone_direct(row,line)

            if char == "x" then
                z.Kind = 1
           

            elsif char == "r" then
                z.Kind = 4
           

            elsif char == "t" then
                monster = Troll.new()
                monster.create(@world,row*40,line*40)
                monster.projectile_images = $Projectiles_images
                monster.images = $Troll_images

         

             elsif char == "l" then
                monster = Lizard.new()
                monster.create(@world,row*40,line*40)
                monster.projectile_images = $Projectiles_images
                monster.images = $Lizard_images


            elsif char == "y" then
                monster = Lermitte.new()
                monster.create(@world,row*40,line*40)
                monster.projectile_images = $Projectiles_images
                monster.images = $Lermitte_images
		
		
	    elsif char == "w" then
                monster = Lermitte2.new()
                monster.create(@world,row*40,line*40)
                monster.projectile_images = $Projectiles_images
                monster.images = $Lermitte2_images

            elsif char == "b" then
                monster = Bat.new()
                monster.create(@world,row*40,line*40)
                monster.projectile_images = $Projectiles_images
                monster.images = $Bat_images


            elsif char == "c" then
                monster = Catroll.new()
                monster.create(@world,row*40,line*40)
                monster.projectile_images = $Projectiles_images
                monster.images = $Catroll_images

            elsif char == "s" then
                monster = Continue.new()
                monster.create(@world,row*40 +20,line*40 +20)
                monster.images = $Item_images

            elsif char == "h" then
                monster = Hearth.new()
                monster.create(@world,row*40 +20,line*40 +20)
                monster.images = $Item_images
		
	     elsif char == ">" then
		p =  Boulder.new(100,0)
		p.create(@world,row*40 +20,line*40 +20)
		p.launch(@world,row*40 +20,line*40 +20,20,16)
		p.images = $boulders_images
		
	    elsif char == "<" then
		p =  Boulder.new(100,0)
		p.create(@world,row*40 +20,line*40 +20)
		p.launch(@world,row*40 +20,line*40 +20,-20,16)
		p.images = $boulders_images
		
		
	    elsif char == "i" then
                monster = Hurt.new(100)
                monster.create(@world,row*40 +20,line*40 )
		z.Kind = 5
		
	    elsif char == "_" then
                monster = Spring.new(@spring,0)
                monster.create(@world,row*40 +20,line*40 + 30 )
		monster.images = $springs_images
		
	    elsif char == ")" then
                monster = Spring.new(@spring,1)
                monster.create(@world,row*40 +20,line*40 + 20 )
		monster.images = $springs_images
		
	    elsif char == "(" then
                monster = Spring.new(@spring,-1)
                monster.create(@world,row*40 +30,line*40 + 20 )
		monster.images = $springs_images
		

            elsif char == "d" then
                monster = Dynamite.new()
                monster.create(@world,row*40 +20,line*40 +20)
                monster.images = $Item_images
		
	    elsif char == "e" then
                monster = Endlevel.new()
                monster.create(@world,row*40 +20,line*40 +30)
                monster.images = $Item_images



            elsif char == "p" then
                @player.create(@world,row*40,line*40)
                @player.projectile_images = $Projectiles_images
		@player.images = $Player_images
                @player.y_restart = line*40
                @player.x_restart = row*40
            end
	  
  end

  def mainloop(sx,sy,fx,fy)
      return unless @player.statusp == 0 
      if  @world.full_calculus == false then

              #sx = 0
              #sy = 0
              #fx = @world.x
              #fy = @world.y
              (sx..fx).each do |x|
                 (sy..fy).each do |y|

                    @world.getzone_direct(x,y).Entities.each do |ent|
                        if ent.status == 0  then
                            ent.mainloop(@world)
                            ent.status = 1 #poru pas jouer deux fois le meme mouvement
                        end
                    end

                end
             end

             # on reset
             (sx..fx).each do |x|
                 (sy..fy).each do |y|

                    @world.getzone_direct(x,y).Entities.each do |ent|
                            ent.status = 0
                    end

                 end
             end

      else
        @world.Ents.each do |ent|
            ent.mainloop(@world)
        end

      end


    end


end

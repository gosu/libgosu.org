
class RandomMap
	 def initialize(x,y)
		 
		    @y = y
		    @x = x
		    
		    @cx = 0
		    @cy = 0
		    
		    @rad = 2
		    
		    @Zones = Array.new(@x){[]}

		    (0..(@x-1)).each do |xx|
		      (0..(@y-1)).each do |yy|
			@Zones[xx][yy]  = "x"
		      end
		    end
		 
	 end
	 
	 def create()
		 
		@cx = rand(@x)
		@cy = rand(@y)
		@Zones[@cx][@cy] = "p"
		
		20.times do 
			
			ax = @cx 
			ay = @cy
			@cx = rand(@x)
			@cy = rand(@y)
			draw_line(ax,ay,@cx,@cy,1 + rand(5))
		end
		
		@Zones[@cx][@cy] = "e"
		
	end
	
	 def draw_line(xa,ya,xb,yb,rad = 1)
		 
		 cx = xa
		 cy = ya
		 
		 loop do
			 
		    paint(cx,cy," ",rad)

		    dx = -cx + xb
		    dy = -cy + yb

		    ox = cx
		    oy = cy

		    if dx == 0 and dy == 0 then
			return true
		    end

		    if dx.abs > dy.abs then
			cx += (dx.abs/dx)
		    else
			cy += (dy.abs/dy)
		    end
		end
		 
	 end
	
	 def paint(x,y,val,rad ,over = false)
		 
		 xs = (x - rad)
		 ys = (y - rad)
		 
		 xe = (x + rad)
		 ye = (y + rad)
		 
		 if xs < 0 then
			 xs = 0
		 end
		 if ys < 0 then
			 ys = 0
		 end
		 if xe < 0 then
			 xe = 0
		 end
		 if ye < 0 then
			 ye = 0
		 end
		 
		 if ye > @y - 1 then
			 ye = @y - 1
		 end
		 
		 if xe > @x - 1 then
			 xe = @x - 1
		 end
		 
		 if ys > @y - 1 then
			 ys = @y - 1
		 end
		 
		 if xs > @x - 1 then
			 xs = @x - 1
		 end
		 
		 if xs > xe then
			 e = xs
			 xs = xe
			 xe = e
		 end
		 
		 if ys > ye then
			 e = ys
			 ys = ye
			 ye = e
		 end
	
		
		(xs..xe).each do |xx|
		      (ys..ys).each do |yy|
			@Zones[xx][yy]  = val if over or @Zones[xx][yy]  == "x" or  @Zones[xx][yy]  == " "
		      end
		    end

		 
		 
	 end
	 
	 def write_file(name = "random.txt")
		 
		   File.open("simplemaps/"+  name, 'w+') {|f| 
		   
		   (0..(@y-1)).each do |y|
		      (0..(@x-1)).each do |x|

			f.write(@Zones[x][y])

		      end
		      f.write("\n")
		    end
	      
		   }
	  
	
	 end
	
end

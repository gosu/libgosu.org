class Monster < Actor
    attr_accessor :projectile_images , :melee_range
    def initialize()
        super()
        @score = 0
        @projectile_images = Array.new

        @attack_delay = 0
        @jump_delay = 0
        @attack_delay_max = 60
        @dmg_projectile = 15
	@dmg_melee = 15
	@melee_range = 20

        @jump_time = 10
        @sleep = 0

    end

    def player_in_sight(world)
        return does_see(world,world.player)
    end

    def in_melee_range(ent)
	return Gosu::distance(@x, @y, ent.x, ent.y) < @melee_range + ent.hitbox.width/2
    end

    def fire(world)

        if @attack_delay > 0 then
            return
        end

        p = Projectile.new(@facing,0,@dmg_projectile,6)
        p.images = @projectile_images
        p.hitbox = RectangleBox.new(10,10)
        p.owner = 1
        p.launch(world,@x,@y -30 ,15,-10)
        animate_attack()

        @attack_delay = @attack_delay_max
    end

    def melee(world)
	    
	if @attack_delay > 0 then
            return
        end
	    #ben oui que le player
	animate_attack()  
	
	if world.player.check_hit_melee(self) then
		world.player.addhp(world,-@dmg_melee)
	end
	
	@attack_delay = @attack_delay_max
	
    end

    def go_left()
        run(-1)
        animate_move()
        @facing = -1
    end

    def go_right()
        run(1)
        animate_move()
        @facing = 1
    end

    def do_jump()
        if @jump_delay  > 0 then
            return
        end
        @jump_delay = @jump_time
        jump()
        animate_jump()
    end

    def animate_idle()
        @animation = 0
    end

    def animate_jump()
        @animation = 1
    end

    def animate_attack()
        @animation = 2
    end

    def animate_move()
        @animation = 3
    end

end

class Troll < Monster

    def initialize()
        super()
        @hp = 10
        @speed = 0.3
        @jump = 15
        @hitbox = RectangleBox.new(19,14)
        @attack_delay_max = 50
        @dmg_projectile = 10
        @dmg_melee = 25
	@melee_range = 10

    end
    
    def fire(world)

        if @attack_delay > 0 then
            return
        end

        p = Projectile.new(@facing,0,@dmg_projectile,4)
        p.images = @projectile_images
        p.hitbox = RectangleBox.new(10,10)
        p.owner = 1
        p.launch(world,@x,@y  ,13 -rand(3),-8)
        animate_attack()

        @attack_delay = @attack_delay_max
    end

    def mainloop(world)

        main_move(world)

        @attack_delay += -1
        @jump_delay += -1


        if @sleep > 0 then
            @sleep += -1
            animate_move()
            run(@facing)
            return
        end



        zone_in_front(world).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 30
                return
              end

        end

        world.getzone(@x , @y ).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 30
                return
              end

        end

        world.getzone(@x + @facing*80, @y ).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 30
                return
              end

        end

        if player_in_sight(world)
            face_player(world)
	    dorun = true

            if (world.player.y - @y).abs > 80 and  ( zone_in_front_down(world).Kind == 0  ) or ( zone_in_front(world).Kind == 1 and world.getzone(@x , @y  ).Kind == 0  ) then
                dorun = false
            end

            fire(world)
	    
	    if (world.player.y - @y).abs > 50 and (world.player.x - @x).abs < 40 then
			return
	    end

            run(@facing) if dorun
            animate_move() if dorun

            if zone_in_front(world).Kind == 1   then
                do_jump()
            end
	
	     world.getzone(@x , @y -40).Entities.each do |ent|

               if ent.class == Projectile and ent.owner == 0 then
                 @facing *= -1
                 do_jump()
                 @sleep = 40
                 return
               end

             end
	
	   world.getzone(@x , @y -80).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 40
                return
              end

            end

        else
            run(@facing)
            animate_move()
            if world.getzone(@x + @facing*40, @y - 40 ).Kind == 1  or zone_in_front_down(world).Kind == 0 or zone_in_front(world).Kind == 1 then
                @facing *= -1
            end

        end
    end

    def jump()
        if  @falling > 0 then

            accy(-@jump)
            accx(@speed*@facing*13)
        end

    end

    def zone_in_front_down(world)
        return world.getzone(@x + @facing*40, @y + 40 )
    end

    def zone_in_front(world)
        return world.getzone(@x + @facing*40, @y )
    end

    def face_player(world)

        if world.player.x - @x > 0 then
            @facing = 1
        else
            @facing = -1
        end

    end


    def animate_idle()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 0
    end

    def animate_jump()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 1
    end

    def animate_attack()
        return unless  @animation_countdown <= 0
        @animation_countdown = 20
        @animation = 2
    end

    def animate_move()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 3
    end

    def draw(dx,dy)

        @blink += -1

        @animation_countdown += -1

        if @blink > 0 then
            if @blink%3 != 1 then
                return
            end
        end

        if @vel_y.abs < 0.5 and @vel_x.abs < 0.5 then
            animate_idle()
        elsif @vel_y.abs > 0.5 and @vel_x.abs  < 0.5  then
            animate_jump()
        end

        if @animation == 0 or @animation == 1  then
           @images[@animation].draw(Integer(@x - dx -@facing*20), Integer(@y - dy -20), 100,@facing,1,0xffffffff)
        elsif @animation == 2
            anim = 2
           @images[anim].draw(Integer(@x - dx -@facing*20), Integer(@y - dy -20), 100,@facing,1,0xffffffff)
        elsif @animation == 3
            anim = 3 +( Gosu::milliseconds()/75) %3
           @images[anim].draw(Integer(@x - dx -@facing*20), Integer(@y - dy -20), 100,@facing,1,0xffffffff)

        end
    end

end

class Catroll < Monster

    def initialize()
        super()
        @hp = 60
        @speed = 0.08
        @jump = 10
        @hitbox = RectangleBox.new(35,55)
        @dmg_melee = 40
	@melee_range = 30
        @friction = 0.9999

    end

    def mainloop(world)

        main_move(world)

        @attack_delay += -1
        @jump_delay += -1


        if player_in_sight(world)
            face_player(world)
	    
	    if in_melee_range(world.player) then
		     melee(world)
		     return
	     end
	     
            run(@facing)
            animate_move()

            if world.player.y < @y - 40  and   world.getzone(@x + @facing*40, @y - 40 ).Kind == 1 then
              do_jump()
            end

            if zone_in_front(world).Kind == 1   then
                do_jump()
            end

        else
            run(@facing)
            animate_move()
            if zone_in_front_down(world).Kind == 0 or zone_in_front(world).Kind == 1 then
                @facing *= -1
            end

        end
      end

    def zone_in_front_down(world)
        return world.getzone(@x + @facing*40, @y + 40 )
    end

    def zone_in_front(world)
        return world.getzone(@x + @facing*40, @y )
    end

    def face_player(world)

        if world.player.x - @x > 0 then
            @facing = 1
        else
            @facing = -1
        end

    end


    def draw(dx,dy)

         @blink += -1

        if @blink > 0 then
             if @blink%2 == 1 then
                return
            end
        end

        if @vel_y.abs < 1 and @vel_x.abs < 1 then
            animate_idle()
        elsif @vel_y.abs > 1 and @vel_x.abs  < 1  then
            animate_jump()
        end
    
         
       if @animation == 0 or @animation == 1  then
           @images[@animation].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 100,@facing,1,0xffffffff)
        elsif @animation == 2
            anim = 2
           @images[anim].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 100,@facing,1,0xffffffff)
        elsif @animation == 3
            anim = 3 +( Gosu::milliseconds()/80) %3
           @images[anim].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 100,@facing,1,0xffffffff)

        end
    end

end

class Lizard < Monster

    def initialize()
        super()
        @hp = 10
        @speed = 0.7
        @jump = 14
        @hitbox = RectangleBox.new(26,22)
        @dmg_melee = 30
	@melee_range = 25

    end

    def mainloop(world)

        main_move(world)

       # return if rand(5) < 3

        @attack_delay += -1
        @jump_delay += -1




        if @sleep > 0 then
            @sleep += -1
            animate_move()
            run(@facing)
            return
        end



        zone_in_front(world).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 40
                return
              end

        end

        world.getzone(@x , @y ).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 40
                return
              end

        end

        world.getzone(@x + @facing*80, @y ).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 40
                return
              end

        end

        world.getzone(@x + @facing*40, @y -40).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 40
                return
              end

        end

        world.getzone(@x + @facing*40, @y +40).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 40
                return
              end

        end
	
	world.getzone(@x , @y -40).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 40
                return
              end

        end
	
	world.getzone(@x , @y -80).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 40
                return
              end

        end


        if player_in_sight(world)
	    if (world.player.y - @y).abs > 50 and (world.player.x - @x).abs < 40 then
			return
	    end
		
            face_player(world)
	    
	    if in_melee_range(world.player) then
		     melee(world)
		     return
	     end
	     
            run(@facing)
            animate_move()

            if world.player.y < @y - 40  and   world.getzone(@x + @facing*40, @y - 40 ).Kind == 1 then
              do_jump()
            end

            if (world.player.y - @y).abs < 40  and   zone_in_front(world).Kind == 0 then
              do_jump()
            end

            if zone_in_front(world).Kind == 1   then
                do_jump()
            end

        else
            run(@facing)
            animate_move()
            if zone_in_front_down(world).Kind == 0 or zone_in_front(world).Kind == 1 then
                @facing *= -1
            end

        end
      end

    def zone_in_front_down(world)
        return world.getzone(@x + @facing*40, @y + 40 )
    end

    def zone_in_front(world)
        return world.getzone(@x + @facing*40, @y )
    end

    def face_player(world)

        if world.player.x - @x > 0 then
            @facing = 1
        else
            @facing = -1
        end

    end

    def jump()
        if  @falling > 0 then

            accy(-@jump)
            accx(@speed*@facing*13)
        end

    end

    def animate_idle()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 0
    end

    def animate_jump()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 1
    end

    def animate_attack()
        return unless  @animation_countdown <= 0
        @animation_countdown = 20
        @animation = 2
    end

    def animate_move()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 3
    end


    def draw(dx,dy)

        @blink += -1

        @animation_countdown += -1

        if @blink > 0 then
            if @blink%3 != 1 then
                return
            end
        end

        if @vel_y.abs < 0.5 and @vel_x.abs < 0.5 then
            animate_idle()
        elsif @vel_y.abs > 0.5 and @vel_x.abs  < 0.5  then
            animate_jump()
        end

        if @animation == 0 or @animation == 1  then
           @images[@animation].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 100,@facing,1,0xffffffff)
        elsif @animation == 2
            anim = 2
           @images[anim].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 100,@facing,1,0xffffffff)
        elsif @animation == 3
            anim = 3 +( Gosu::milliseconds()/60) %3
           @images[anim].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 100,@facing,1,0xffffffff)

        end
    end

end

class Lermitte < Monster

    def initialize()
        super()
        @hp = 20
        @speed = 0.2
        @jump = 10
        @hitbox = RectangleBox.new(19,26)
        @dmg_melee = 20
	@melee_range = 20
        @jump_time = 10

    end

    def mainloop(world)

	
        main_move(world)

        @attack_delay += -1
        @jump_delay += -1

	

        if @sleep > 0 then
            @sleep += -1
            animate_move()
            run(@facing)
            return
	end


	
        zone_in_front(world).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 30
                return
              end

        end

        world.getzone(@x , @y ).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 30
                return
              end

        end

        world.getzone(@x + @facing*80, @y ).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 30
                return
              end

        end

        world.getzone(@x + @facing*40, @y -40).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 30
                return
              end

        end

        world.getzone(@x + @facing*40, @y +40).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 30
                return
              end

        end
	
	world.getzone(@x , @y -40).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 40
                return
              end

        end
	
	world.getzone(@x , @y -80).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                @facing *= -1
                do_jump()
                @sleep = 40
                return
              end

        end


        if player_in_sight(world)
            face_player(world)

            if (world.player.y - @y).abs > 80 and  ( zone_in_front_down(world).Kind == 0 and world.getzone(@x , @y + 40 ).Kind == 0  ) or ( zone_in_front(world).Kind == 1 and world.getzone(@x , @y  ).Kind == 0  ) then
                @facing *= -1
	    end
	
	
	
	    if (world.player.y - @y).abs > 50 and (world.player.x - @x).abs < 40 then
			return
	    end
		
	    if in_melee_range(world.player) then
		     melee(world)
		     return
	    end
	
            run(@facing)
            animate_move()

            if world.player.y < @y - 40  and   world.getzone(@x + @facing*40, @y - 40 ).Kind == 1 then
              do_jump()
            end
      
            if (world.player.y - @y).abs < 40  and   zone_in_front(world).Kind == 0 then
              do_jump()
            end


            if zone_in_front(world).Kind == 1   then
                do_jump()
	    end
	



        else
            run(@facing)
            animate_move()
            if ( zone_in_front_down(world).Kind == 0 and world.getzone(@x , @y + 40 ).Kind == 0  ) or ( zone_in_front(world).Kind == 1 and world.getzone(@x , @y  ).Kind == 0  ) then
                @facing *= -1
            end

        end
      end

    def zone_in_front_down(world)
        return world.getzone(@x + @facing*40, @y + 40 )
    end

    def zone_in_front(world)
        return world.getzone(@x + @facing*40, @y )
    end

    def face_player(world)

        if world.player.x - @x > 0 then
            @facing = 1
        else
            @facing = -1
        end

    end

    def jump()
        if  @falling > 0 then

            accy(-@jump)
            accx(@speed*@facing*13)
        end

    end


    def animate_idle()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 0
    end

    def animate_jump()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 1
    end

    def animate_attack()
        return unless  @animation_countdown <= 0
        @animation_countdown = 20
        @animation = 2
    end

    def animate_move()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 4
    end

    def draw(dx,dy)

        @blink += -1

        @animation_countdown += -1

        if @blink > 0 then
            if @blink%3 != 1 then
                return
            end
        end

        if @vel_y.abs < 0.5 and @vel_x.abs < 0.5 then
            animate_idle()
        elsif @vel_y.abs > 0.5 and @vel_x.abs  < 0.5  then
            animate_jump()
        end

        if @animation == 0 or @animation == 1  then
           @images[@animation].draw(Integer(@x - dx -@facing*18), Integer(@y - dy -20), 100,@facing,1,0xffffffff)
        elsif @animation == 2
        
	    anim = @animation +( Gosu::milliseconds()/190) %2
           @images[anim].draw(Integer(@x - dx -@facing*18), Integer(@y - dy -20), 100,@facing,1,0xffffffff)
        elsif @animation == 4
            anim = @animation +( Gosu::milliseconds()/190) %3
           @images[anim].draw(Integer(@x - dx -@facing*18), Integer(@y - dy -20), 100,@facing,1,0xffffffff)

        end
    end



end

class Lermitte2 < Monster

    def initialize()
        super()
        @hp = 20
        @speed = 0.55
        @jump = 16
        @hitbox = RectangleBox.new(19,26)
        @dmg_melee = 20
	@melee_range = 15
        @jump_time = 10
	
	@is_retreating = 0
	
	@will_be_cautious = rand(2) == 0 ? true : false
	@caution_distance = rand(7)*10 + 100
	

    end

    def mainloop(world)


        main_move(world)

        @attack_delay += -1
        @jump_delay += -1
	
	@is_retreating += -1



        if @sleep > 0 then
            @sleep += -1
            animate_move()
            run(@facing)
            return
        end
    
        

	if  (world.player.x - @x).abs > 70 or (world.player.y - @y).abs > 70  then
		

		zone_in_front(world).Entities.each do |ent|

		      if ent.class == Projectile and ent.owner == 0 and ent.vel_x*@vel_x < 0 then
			@facing *= -1
			do_jump()
			@sleep = 20
			return
		      end

		end

		world.getzone(@x , @y ).Entities.each do |ent|

		      if ent.class == Projectile and ent.owner == 0 and ent.vel_x*@vel_x > 0 then
			@facing *= -1
			do_jump()
			@sleep = 20
			return
		      end

		end

		world.getzone(@x + @facing*80, @y ).Entities.each do |ent|

		      if ent.class == Projectile and ent.owner == 0 and ent.vel_x*@vel_x < 0 then
			@facing *= -1
			do_jump()
			@sleep = 20
			return
		      end

		end

		world.getzone(@x + @facing*40, @y -40).Entities.each do |ent|

		      if ent.class == Projectile and ent.owner == 0 and ent.vel_x*@vel_x > 0 then
			@facing *= -1
			@sleep = 20
			return
		      end

		end

		world.getzone(@x + @facing*40, @y +40).Entities.each do |ent|

		      if ent.class == Projectile and ent.owner == 0 and ent.vel_x*@vel_x < 0 then
			@facing *= -1
			do_jump()
			@sleep = 20
			return
		      end

		end
		
		world.getzone(@x , @y -40).Entities.each do |ent|

		      if ent.class == Projectile and ent.owner == 0 and ent.vel_x*@vel_x > 0 then
			@facing *= -1
			@sleep = 20
			return
		      end

		end
		
		world.getzone(@x , @y -80).Entities.each do |ent|

		      if ent.class == Projectile and ent.owner == 0 and ent.vel_x*@vel_x > 0 then
			@facing *= -1
			@sleep = 20
			return
		      end

		end
	end

        if player_in_sight(world)
		if @is_retreating <= 0 then
		    face_player(world)
		    
		    if in_melee_range(world.player) then
		     melee(world)
		     return
		    end

		    if (world.player.y - @y).abs > 80 and  ( zone_in_front_down(world).Kind == 0 and world.getzone(@x , @y + 40 ).Kind == 0  ) or ( zone_in_front(world).Kind == 1 and world.getzone(@x , @y  ).Kind == 0  ) then
			@facing *= -1
	            end
		
		    if  @will_be_cautious and (world.player.y - @y).abs < 70 and (world.player.x - @x).abs < @caution_distance and (world.player.x - @x).abs > 50  and world.player.attack_delay < 1 and @facing * world.player.facing < 0 then
			  return
		    end
		    
	     
	            if ((world.player.x - @x).abs < 80 and ( world.player.y - @y ).abs < 40)  and world.player.vel_y < 0 then
		      do_jump()
		    end

		
		  if @falling >= 1 then
				   if world.getzone(@x + @facing*5, @y - 40 ).Kind == 1 then
					do_jump()   
				  end
				  if world.getzone(@x + @facing*5, @y ).Kind == 1 then
					do_jump()   
				  end
				
				   if world.getzone(@x + @facing*5, @y + 40 ).Kind == 0 then
					   if world.getzone(@x + @facing*90, @y + 40 ).Kind == 1 then
					     do_jump()   
					     
					     else 
						     @is_retreating = 160
						     @facing *= -1
					   end
				   end
			   end
		    run(@facing)
		    animate_move()
		else
			run(@facing)
			animate_move()
			
			 if world.getzone(@x + @facing*5, @y - 40 ).Kind == 1 then
				do_jump()   
			  end
			  if world.getzone(@x + @facing*5, @y ).Kind == 1 then
				do_jump()   
			  end
			
			   if world.getzone(@x + @facing*5, @y + 40 ).Kind == 0 then
				   if world.getzone(@x + @facing*90, @y + 40 ).Kind == 1 then
				     do_jump()   
				     
				     else 
					     @is_retreating = 0
					     @facing *= -1
				   end
			   end
			   if ( zone_in_front_down(world).Kind == 0 and world.getzone(@x , @y + 40 ).Kind == 0  ) or ( zone_in_front(world).Kind == 1 and world.getzone(@x , @y  ).Kind == 0  ) then
				@is_retreating = 0
				@facing *= -1
			  end
			
		end


        else
            
            if ( zone_in_front_down(world).Kind == 0 and world.getzone(@x , @y + 40 ).Kind == 0  ) or ( zone_in_front(world).Kind == 1 and world.getzone(@x , @y  ).Kind == 0  ) then
                @facing *= -1
            end


        end
    end

    def retreat(world)
	    
    end

    def zone_in_front_down(world)
        return world.getzone(@x + @facing*40, @y + 40 )
    end

    def zone_in_front(world)
        return world.getzone(@x + @facing*40, @y )
    end

    def face_player(world)

        if world.player.x - @x > 0 then
            @facing = 1
        else
            @facing = -1
        end

    end

    def jump()
        if  @falling > 0 then
            accy(-@jump)
            accx(@speed*@facing*3)
        end

    end


    def animate_idle()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 0
    end

    def animate_jump()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 1
    end

    def animate_attack()
        return unless  @animation_countdown <= 0
        @animation_countdown = 20
        @animation = 2
    end

    def animate_move()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 3
    end

    def draw(dx,dy)

        @blink += -1

        @animation_countdown += -1

        if @blink > 0 then
            if @blink%3 != 1 then
                return
            end
        end

        if @vel_y.abs < 0.5 and @vel_x.abs < 0.5 then
            animate_idle()
        elsif @vel_y.abs > 0.5 and @vel_x.abs  < 0.5  then
            animate_jump()
        end

        if @animation == 0 or @animation == 1  then
           @images[@animation].draw(Integer(@x - dx -@facing*18), Integer(@y - dy -20), 100,@facing,1,0xffffffff)
        elsif @animation == 2
            anim = 2
           @images[anim].draw(Integer(@x - dx -@facing*18), Integer(@y - dy -20), 100,@facing,1,0xffffffff)
        elsif @animation == 3
            anim = 3 +( Gosu::milliseconds()/70) %3
           @images[anim].draw(Integer(@x - dx -@facing*18), Integer(@y - dy -20), 100,@facing,1,0xffffffff)

        end
    end



end


class Bat < Monster

    def initialize()
        super()
        @hp = 10
        @speed = 0.2
        @jump = 7
        @hitbox = RectangleBox.new(36,38)
        @dmg_melee = 20
	@melee_range = 20

        @friction = 0.99

        @jump_time = 5

        @randotime = rand(80)

    end

    def jump()

        accy(-@jump)

    end

    def mainloop(world)

        main_move(world)

        @attack_delay += -1
        @jump_delay += -1

        @randotime  += -1

        if @randotime < 0 then
          do_jump()
          @randotime = rand(140)
        end

        zone_in_front(world).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                do_jump()
              end

        end

       world.getzone(@x + @facing*80, @y + 20 ).Entities.each do |ent|

              if ent.class == Projectile and ent.owner == 0 then
                do_jump()
              end

        end

        if player_in_sight(world)
            face_player(world)
	    
	    if in_melee_range(world.player) then
		     melee(world)
		     return
	     end
	     
            run(@facing)
            animate_move()

            if world.player.y < @y     then
              do_jump()
            end

        else
            run(@facing)
            animate_move()

            if world.getzone(@x , @y + 40 ).Kind == 1 then
              do_jump()
            end

            if world.getzone(@x , @y + 80 ).Kind == 1 then
              do_jump()
            end

            if  zone_in_front(world).Kind == 1 then
                @facing *= -1
            end

        end
      end

    def zone_in_front_down(world)
        return world.getzone(@x + @facing*40, @y + 40 )
    end

    def zone_in_front(world)
        return world.getzone(@x + @facing*40, @y )
    end

    def face_player(world)

        if world.player.x - @x > 0 then
            @facing = 1
        else
            @facing = -1
        end

    end


    def draw(dx,dy)

        @blink += -1
        if @blink > 0 then
             if @blink%2 == 1 then
                return
            end
        end

     
        @images[3 - ( Gosu::milliseconds()/30) %3 ].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 99,@facing,1,0xffffffff)
    end

end
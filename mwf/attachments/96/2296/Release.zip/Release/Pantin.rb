
class ManPantin
	def initialize()
		
		@torso = Part.new($Pantin_images[1],0,0,15)
		@head = Part.new($Pantin_images[0],0,-20,15)
		@leg1 = Part.new($Pantin_images[2],0,20,15)
		@leg2 = Part.new($Pantin_images[2],0,16,15)
		@foot = Part.new($Pantin_images[3],0,12,15)
		
		#@torso.parts.push(@head)
		@torso.parts.push(@leg1)
		#@leg1.parts.push(@leg2)
		#@leg2.parts.push(@foot)
		
		@torso.rotation = 90
		
		
	end
	
	def draw(x,y)
		
		@torso.draw(x,y,0)
		
	end
	
end


class Part
	attr_accessor :parent_x,:parent_y , :parts ,:rotation
	def initialize(image,x,y,sq)
		@image = image
		@rotation = 0
		@parts = Array.new()
		
		@facing = 1
		
		@parent_x = x
		@parent_y = y
		
		@sq = sq
	end
	
	def draw(x,y,rotation)
		
		@image.draw_rot(x - @sq, y - @sq,@facing, @rotation + rotation)
		
		@parts.each do |p|
			p.draw(x + Gosu::offset_x(@facing*(@rotation+rotation) + 90, p.parent_x),y + Gosu::offset_y(@facing*(@rotation+rotation) + 180, p.parent_y),@rotation)
		end
	end
	
end
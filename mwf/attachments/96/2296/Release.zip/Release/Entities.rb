﻿
class Hurt < Entity
    def initialize(dmg)
        super()
        @hitbox = RectangleBox.new(30,4)
	@dmg = dmg
    end
    def addhp(world,dmg) 
	    destroy(world)
    end
    def mainloop(world)
         delta = 40

        ix = world.gdx(x-delta)
        fx = world.gdx(x+delta)

        iy = world.gdy(y-delta)
        fy = world.gdy(y+delta)

        # on ne teste que les cases adjacentes
        (ix..fx).each do |xx|
            (iy..fy).each do |yy|

                world.getzone_direct(xx,yy).Entities.each do |ent|
                        if  ent.class != Effect and ent.class != Bomb and ent.class != Boulder and ent.class != Hurt and ent.class != Endlevel and ent.class != Hearth and ent.class != Projectile and ent.class != Continue and ent.class != Dynamite then
                            if check_collide(ent) then

                                if ent.class == Player then
                                   
					ent.addhp(world,-@dmg)
                                    

                                else
                                  
					ent.addhp(world,-@dmg)
                                  
                                end
                            end
                        end

                    end
            end

        end
    end

    def draw(dx,dy)
       return
    end
end

class Spring < Entity
    def initialize(vel,dir)
        super()
	@anim_delay = 0
	@vel = vel
	@dir = dir
	
	if dir == 0 then
	   @hitbox = RectangleBox.new(30,10)
	else
	   @hitbox = RectangleBox.new(10,30)	
	end
    end
    def addhp(world,dmg) 
	    destroy(world)
    end
    def mainloop(world)
	    
	 @anim_delay += -1
	 
	 return unless @anim_delay <= 0
	    
         delta = 40

        ix = world.gdx(x-delta)
        fx = world.gdx(x+delta)

        iy = world.gdy(y-delta)
        fy = world.gdy(y+delta)

        # on ne teste que les cases adjacentes
        (ix..fx).each do |xx|
            (iy..fy).each do |yy|

                world.getzone_direct(xx,yy).Entities.each do |ent|
                        if ent.class != Spring and  ent.class != Effect  and ent.class != Hurt and ent.class != Endlevel and ent.class != Hearth  and ent.class != Continue  then
                            if check_collide(ent) then
				    
				if @dir == 0 then
				  ent.vel_y = -@vel 
				elsif @dir == 1
				  ent.vel_x = @vel 
				  ent.accy(-3)
				elsif @dir == -1
				  ent.vel_x = -@vel 
				  ent.accy(-3)				  
				end
				
				@anim_delay = 10
                            end
                        end

                    end
            end

        end
    end

    def draw(dx,dy)
	    
	    if @dir == 0
	    
		    if @anim_delay <= 0 then
			@images[0][0].draw(Integer(@x - dx -20), Integer(@y - dy -30), 50,1,1,0xffffffff) 
		    else
			@images[0][1].draw(Integer(@x - dx -20), Integer(@y - dy -30), 50,1,1,0xffffffff) 
		   end
	    elsif @dir == 1
		    
		   if @anim_delay <= 0 then
			@images[1][0].draw(Integer(@x - dx -20), Integer(@y - dy -20), 50,@dir,1,0xffffffff) 
		    else
			@images[1][1].draw(Integer(@x - dx -20), Integer(@y - dy -20), 50,@dir,1,0xffffffff) 
		    end
		
	    elsif @dir == -1
		    if @anim_delay <= 0 then
			@images[1][0].draw(Integer(@x - dx +10), Integer(@y - dy -20), 50,@dir,1,0xffffffff) 
		    else
			@images[1][1].draw(Integer(@x - dx +10), Integer(@y - dy -20), 50,@dir,1,0xffffffff) 
		    end
           end
    end
end

class Endlevel < Entity
    def initialize()
        super()
        @hitbox = RectangleBox.new(8,8)
    end
    def mainloop(world)
        if check_collide(world.player) then
            world.player.statusp = 2
        end
    end

    def draw(dx,dy)
        @images[3].draw(Integer(@x - dx -20), Integer(@y - dy -30), 50,1,1,0xffffffff)
    end
end

class Continue < Entity
    def initialize()
        super()
        @hitbox = RectangleBox.new(34,34)
    end

    def mainloop(world)
        if check_collide(world.player) then
            world.player.y_restart = @y
            world.player.x_restart = @x
            world.player.hp = 100
            destroy(world)
        end
    end

    def draw(dx,dy)
        @images[0].draw(Integer(@x - dx -17), Integer(@y - dy -17), 50,1,1,0xffffffff)
    end
end

class Hearth < Entity
    def initialize()
        super()
        @hitbox = RectangleBox.new(20,20)
    end

    def mainloop(world)
        if check_collide(world.player) then
            world.player.addhp(world, 20 )
            destroy(world)
        end
    end

    def draw(dx,dy)
        @images[1].draw(Integer(@x - dx -10), Integer(@y - dy -10), 50,1,1,0xffffffff)
    end
end

class Dynamite < Entity
    def initialize()
        super()
        @hitbox = RectangleBox.new(20,20)
    end

    def mainloop(world)
        if check_collide(world.player) then
            world.player.bombs += 3
            destroy(world)
        end
    end

    def draw(dx,dy)
        @images[2].draw(Integer(@x - dx -10), Integer(@y - dy -10), 50,1,1,0xffffffff)
    end
end


class Projectile < PhysEnt
    attr_accessor :owner , :animation
    def initialize(facing,owner,dmg,image)
        super()

        @friction = 0.97
        @bouncyness = 0.7

        @animation = image # c'est le numero de l'image utilisée

        @hitbox = RectangleBox.new(40,40)

        @facing = facing

        @dmg = dmg

        @owner = owner

        @countdown = 100

    end

    def launch(world,x,y,xs,ys)
        create(world,x,y)

        accx(xs*@facing)
        accy(ys)
    end

    def stop(world)
        @vel_x = 0
        @vel_y = 0
        destroy(world)
    end

    def die(world)
        destroy(world)
    end

    def mainloop(world)
        main_move(world)

        @countdown += -1
        if @countdown < 0 then
          die(world)
          return
        end

        if @falling == 3
          stop(world)
          return
        end




        delta = 40

        ix = world.gdx(x-delta)
        fx = world.gdx(x+delta)

        iy = world.gdy(y-delta)
        fy = world.gdy(y+delta)

        # on ne teste que les cases adjacentes
        (ix..fx).each do |xx|
            (iy..fy).each do |yy|

                world.getzone_direct(xx,yy).Entities.each do |ent|
                        if @falling < 3  and  ent.class != Spring and   ent.class != Effect  and ent.class != Boulder and ent.class != Hurt and ent.class != Bomb and ent.class != Endlevel and ent.class != Hearth and ent.class != Projectile and ent.class != Continue and ent.class != Dynamite then
                            if check_collide(ent) then

                                if ent.class == Player then
                                    if  @owner != 0
                                        ent.addhp(world,-@dmg)
                                        destroy(world)
                                    end

                                else
                                    if  @owner == 0 
                                        ent.addhp(world,-@dmg)
                                        destroy(world)
                                    end
                                end
                            end
                        end

                    end
            end

        end


    end

    def draw(dx,dy)
        if @vel_x > 0
            @facing = 1
        elsif @vel_x < 0
           @facing = -1
        end

        anim = ( Gosu::milliseconds()/190) %@images[@animation].size

        @images[@animation][anim].draw(Integer(@x - dx -@facing*15), Integer(@y - dy -15), 150,@facing,1,0xffffffff)
    end
end


class Boulder < PhysEnt
    attr_accessor :owner , :animation
    def initialize(dmg,image)
        super()

        @friction = 0.9997
        @bouncyness = 0.5

        @animation = image # c'est le numero de l'image utilisée

        @hitbox = RectangleBox.new(34,34)

        @dmg = dmg

        @countdown = 100
	
	@angle = 0
	
	

    end

    def launch(world,x,y,xs,ys)
        create(world,x,y)

        accx(xs)
        accy(ys)
    end

    def stop(world)
      
    end

    def die(world)
	3.times do
		
		ef = Effect.new($Effects_images,24,2)
		x = ( 10 - rand(20) ) 
		y = ( 10 - rand(20) ) 
		ef.teleport(world,x+@x,y +@y)
		ef.friction = 0.9999
		
		ef.vel_x = (10 - rand(20)).to_f / 5 + @vel_x
		ef.vel_y = (  - rand(40)).to_f / 5 + @vel_y
		
		
	end
        destroy(world)
    end

    def mainloop(world)
        main_move(world)

        @countdown += -1
        

        delta = 40

        ix = world.gdx(x-delta)
        fx = world.gdx(x+delta)

        iy = world.gdy(y-delta)
        fy = world.gdy(y+delta)
	
	if not ( (@vel_x).abs + (@vel_y).abs > 2 )
		 if @countdown < 0 then
			die(world)
			return
		 end
		return
        end
	
	@countdown = 100
       
        # on ne teste que les cases adjacentes
        (ix..fx).each do |xx|
            (iy..fy).each do |yy|

                world.getzone_direct(xx,yy).Entities.each do |ent|
                        if   ent.class != Effect and ent.class != Boulder  and ent.class != Spring  and ent.class != Hurt and ent.class != Bomb and ent.class != Endlevel and ent.class != Hearth and ent.class != Projectile and ent.class != Continue and ent.class != Dynamite then
                            if check_collide(ent) then

                                if ent.class == Player then
                                        ent.addhp(world,-@dmg)
                                else
                                        ent.addhp(world,-@dmg)
                                     
                                end
                            end
                        end

                    end
            end

        end


    end

    def draw(dx,dy)
	    
        @angle = (@angle + @vel_x*4)%360
	
        @images[@animation][0].draw_rot(Integer(@x - dx ), Integer(@y - dy), 130,@angle)
    end
end



class Bomb < Projectile
    def initialize(facing,owner,dmg,image)
        super(facing,owner,dmg,image)
        @countdown = 70
    end

    def stop(world)
        @vel_x = 0
        @vel_y = 0
    end

    def die(world)
        world.dig_small_hole(@x,@y)
	
	4.times do
		
		ef = Effect.new($Effects_images,24,0)
		x = ( 50 - rand(100) ) 
		y = ( 50 - rand(100) ) 
		ef.teleport(world,x+@x,y +@y)
		ef.friction = 0.96
		
		ef.vel_x = (50 - rand(100)).to_f / 5
		ef.vel_y = (50 - rand(100)).to_f / 5
		
		
	end
	
	3.times do
		
		ef = Effect.new($Effects_images,30,2)
		x = ( 30 - rand(60) ) 
		y = ( 30 - rand(60) ) 
		ef.friction = 0.96
		ef.teleport(world,x+@x,y +@y)
		
		ef.vel_x = (50 - rand(100)).to_f / 5
		ef.vel_y = (50 - rand(100)).to_f / 5
		
		
	end
	
        destroy(world)
    end

    def mainloop(world)
        main_move(world)

        @countdown += -1
        if @countdown < 0 then
          die(world)
          return
        end

        if @falling == 3
          stop(world)
          return
        end


    end

    def draw(dx,dy)
        if @vel_x > 0
            @facing = 1
        elsif @vel_x < 0
           @facing = -1
        end

        anim = 14 - ( @countdown*14/70) %@images[@animation].size

        @images[@animation][anim].draw(Integer(@x - dx -@facing*15), Integer(@y - dy -15), 150,@facing,1,0xffffffff)
    end

end




class Player < Actor
    attr_accessor :projectile_images , :x_restart,:y_restart,:bombs,:statusp , :attack_delay,:vitality,:energy,:strength,:agility 
    def initialize()
        super()
        @score = 0
        @projectile_images = Array.new
        @hitbox = RectangleBox.new(18,34)

	@hp = 100
	@maxhp = 100
	
	
	@vitality = 10
	@energy = 10
	@strength = 10
	@agility = 10
	

        @attack_delay = 0
	
	

        @x_restart = @x
        @y_restart = @y

        @jump_delay = 0

        @bombs = 0
	
	@statusp = 0 # 0 en cours , 1 perdus , 2 gagne
	
	#@pantin = ManPantin.new()

    end
    
    def destroy(world)
	    @statusp = 1
	    super(world)
    end


    def firesecondary(world)
        if @attack_delay > 0 then
            return
        end

        p = Projectile.new(@facing,0,10,rand(1))
        p.hitbox = RectangleBox.new(36,6)
        p.images = @projectile_images
        p.launch(world,@x -@facing*20,@y -5 ,20,0)
        animate_attack()

        @attack_delay = 40
    end

    def fire(world)
        if @attack_delay > 0 then
            return
        end

        p = Projectile.new(@facing,0,10,rand(1))
        p.hitbox = RectangleBox.new(36,6)
        p.images = @projectile_images
        p.launch(world,@x-@facing*20,@y -5 ,17,-5)
        animate_attack()

        @attack_delay = 40
	
    end



    def fire_bomb(world)
        if @attack_delay > 0 or @bombs <= 0  then
            return
        end

        @bombs += -1

        p = Bomb.new(@facing,0,10,5)
        p.hitbox = RectangleBox.new(24,6)
        p.images = @projectile_images
        p.launch(world,@x-@facing*20,@y -5 ,17,-2)

        animate_attack()

        @attack_delay = 15
    end

    def go_left()
        run(-1)
        animate_move()
        @facing = -1
    end

    def go_right()
        run(1)
        animate_move()
        @facing = 1
	end

    def go_left_b()
        run(-1)
        animate_move()
        @facing = 1
    end

    def go_right_b()
        run(1)
        animate_move()
        @facing = -1
    end

    def do_jump()
        if @jump_delay  > 0 then
            return
        end
        @jump_delay = 15
        jump()
        animate_jump()
    end

    def animate_idle()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 0
    end

    def animate_jump()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 1
    end

    def animate_attack()
        return unless  @animation_countdown <= 0
        @animation_countdown = 10
        @animation = 3
    end

    def animate_move()
        return unless  @animation_countdown <= 0
        @animation_countdown = 0
        @animation = 4
    end

    def draw(dx,dy)
	if @statusp == 2 then 
		return 
	end
        @blink += -1

        @animation_countdown += -1

        if @blink > 0 then
            if @blink%3 != 1 then
                return
            end
        end

        if @vel_y.abs < 1 and @vel_x.abs < 1 then
            animate_idle()
        elsif @falling < 0  then
            animate_jump()
        end

        if @animation == 0  then
		@images[@animation].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 100,@facing,1,0xffffffff)
	elsif  @animation == 1
            @images[@animation].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 100,@facing,1,0xffffffff)
        elsif @animation == 3
            anim = 4 + Integer( (10-@animation_countdown)*5/10)
            if anim > 8 then
                anim =8
            end
            @images[anim].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 100,@facing,1,0xffffffff)
        elsif @animation == 4
            anim = 2 +( Gosu::milliseconds()/70) %3
            @images[anim].draw(Integer(@x - dx -@facing*36), Integer(@y - dy -36), 100,@facing,1,0xffffffff)

        end
	
	#@pantin.draw(Integer(@x - dx),Integer(@y - dy ))
    end

    def mainloop(world)
        main_move(world)
        @attack_delay += -1
        @jump_delay += -1


    end

end
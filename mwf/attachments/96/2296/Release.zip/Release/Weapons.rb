class Weapon
	attr_accessor :image ,:inventory_image ,:damage,:rate
    def initialize(img,img2,dmg,rtf)
	@image = img
	@inventory_image = img2
	@damage = dmg
	@rate = rtf
    end

end

class RangedWeap < Weapon
   def initialize(img,img2,dmg,rtf)
	super(img,img2,dmg,rtf)
	
end
end
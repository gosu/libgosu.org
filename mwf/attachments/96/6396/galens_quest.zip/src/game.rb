#!/usr/bin/env ruby

Dir.chdir(File.dirname(__FILE__))
$:.unshift(File.dirname(__FILE__))
$:.unshift(File.expand_path('../lib'))

require 'rubygems'
require 'gosu'
include Gosu

require 'lib.rb'
require 'lib_misc.rb'
require 'lib_medialoader.rb'
require 'lib_alphabet.rb'
include EveryModule

$VERBOSE = true

def draw_square(window, x, y, z, width, height, color = 0xffffffff)
  window.draw_quad(x, y, color, x + width, y, color, x, y + height, color, x + width, y + height, color, z)
end


class GameWindow < Gosu::Window
  def initialize()
    super(1280, 960, false)
    self.caption = 'Galen\'s Quest'
    begin
      Gosu::enable_undocumented_retrofication() # Disable bilinear filtering
      vputs 'Bilinear filtering is off.'
    rescue
      vputs 'Bilinear filtering is on'
    end
    Media::initialize(self, '../images', '../sounds')
    Alphabet::initialize(self)
    @fps = FPSCounter.new()
    @controller = Controller.new(self)
  end # End GameWindow Initialize
  
  def update()
    @fps.register_tick()
    @controller.update()
  end # End GameWindow Update
  
  def draw()
    clip_to(0, 0, 1280, 960) do
      #Alphabet::draw_text(@fps.fps, 8, 8, 10, 4)
      @controller.draw()
    end
  end # End GameWindow Draw
  
  def button_down(id)
    @controller.button_down(id)
  end
  
  def needs_cursor?()
    return true
  end
end # End GameWindow class


class Controller
  def initialize(window)
    @window = window
    @loader = Mainloader.new(window)
  end
  
  def update()
    every(6) do
      @loader.update()
    end
  end
  
  def draw()
    @loader.draw()
  end
  
  def button_down(id)
  end
end


class Mainloader
  def initialize(window)
    @window = window
    @load_order = ['Engine', 'Graphical Assets', 'Auditory Assets', 'Level data', 'Monster data', 'Player data', 'Grass', 'Birds', 'Oxygen', 'Physics', 'Solar System', 'Alien species', 'Nosferatu', 'Gosu']
    @current_load_index = 0
    @current_progress = 0
  end
  
  def update()
    if @current_progress == 100 then
      @current_load_index += 1 if @current_load_index < @load_order.count() - 1
      @current_progress = 0
    end
    
    if rand(10) == 0 then
      @current_progress += rand(10)
      @current_progress = 100 if @current_progress > 100
    end
  end
  
  def draw()
    Alphabet::draw_text("Loading: #{@load_order[@current_load_index]}", 128, 416, 10, 5)
    Alphabet::draw_text("#{@current_progress}%", 128, 460, 10, 5)
    draw_square(@window, 128, 512, 0, 1024, 32)
    draw_square(@window, 132, 516, 0, (1016 * (@current_progress / 100.0)), 24, 0xFF323232)
  end
end


class Particle
  attr_accessor :tick, :speed, :angle
  
  def initialize(x,y, size_range, rgb)
    @size = random(size_range[0],size_range[1])
    @x = x-(@size/2)
    @y = y-(@size/2)
    @tick = @speed = @angle = 0
    @rgb = rgb
    @color = Gosu::Color.rgba(rgb[0], rgb[1], rgb[2], 200)
  end
  
  def update_color(alpha, black=false)
    if black then
      @color = Gosu::Color.rgba(alpha, alpha, alpha, alpha)
    else
      @color = Gosu::Color.rgba(@rgb[0], @rgb[1], @rgb[2], alpha)
    end
  end
  
  def move()
    @x += Gosu::offset_x(@angle, @speed)
    @y += Gosu::offset_y(@angle, @speed)
  end
  
  def draw(window, z=0)
    window.draw_quad( @x, @y, @color, @x + @size, @y, @color, @x, @y + @size, @color, @x + @size, @y + @size, @color, z, :default )
  end
end


srand()
window = GameWindow.new().show()


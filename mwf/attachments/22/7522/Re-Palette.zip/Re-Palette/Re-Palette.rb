require 'gosu'
require 'ashton' #remember to replace shader.rb
include Gosu

class GameWindow < Gosu::Window
  def initialize
    super(640, 480, false)
    self.caption = "Test Game"
    
    @image=Image.new(self,'image.png')
    
    @pal=Image.new(self,'palette.png') #2-row line of colors ; upper color is replaced by lower ; max length is 32
    @image2=recolor(@image,@pal)
  end

  def update
  end

  def draw
    @image.draw(32,32,0)
    @image2.draw(304,32,0)
  end

  def button_down(id)
  end
  
  def recolor(image,palette) #copy this method to your game ; produces recolored image
    @palette||=Ashton::Shader.new(fragment: "Palette.frag")
    src,dst=[],[]
    palette=palette.to_texture
    
    palette.width.times{|x|
      src << palette[x,0]
      dst << palette[x,1]}
    
    @palette.Src=src
    @palette.Dst=dst
    @palette.Count=src.length
    
    new=Ashton::Texture.new(image.width,image.height)
    @palette.enable #passing :shader => @palette in image.draw causes bug
    new.render{image.draw(0,image.height,0,1,-1)} #texure appears upside-down so drawing needs to be inverted
    @palette.disable
    new.to_image
  end
end

GameWindow.new.show
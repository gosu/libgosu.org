uniform sampler2D in_Texture;

uniform vec4[32] in_Src;
uniform vec4[32] in_Dst;
uniform int in_Count;

varying vec2 var_TexCoord;

void main()
{
  vec4 color = texture2D(in_Texture, var_TexCoord);
  for (int i ; i<in_Count ; i++)
  {
    if (color==in_Src[i])
    {
      gl_FragColor = in_Dst[i];
      break;
    }
    else
    { 
      gl_FragColor = color;
    }
  }
}
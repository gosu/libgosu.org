class MultiLineTextbox
  attr_accessor :x, :y, :color, :text, :font, :padding
  
  def initialize options = {}
    @x, @y = options[:pos]  || [0, 0]
    @width, @height = options[:size] || [$window.width, $window.height / 3]
    @color = options[:color] || Float::INFINITY
    
    self.padding = options[:padding] || 8
    self.font    = options[:font]
    
  end
  
  def draw
    x, y = @x + @padding, @y + @padding

    @lines.each do |range|
      range = (range.first...@reveal.floor) if range.last > @reveal unless @reveal.nil?
      @font.draw text[range], x, y, color
      y += @font.height
    end
  end
  
  
  protected
  
  
  def calculate_lines
    return unless @font and @text and @padding
    calculate_line_ranges ## Makes an array of line ranges called @lines
    calculate_visible_lines ## Calculates @visible_lines
    calculate_last_character_index ## @last_character_index
  end
  
  
  
  def calculate_line_ranges
    @lines = []
    
    box_width = @width - @padding * 2
    first_index = 0
    last_index = test_index = @text.index(/\s|$/) ## Search for the index for the next space or linebreak
    
    while test_index
      test_text = @text[first_index...test_index]
      
      if @font.text_width(test_text) >= box_width
        ## Add the line range to lines
        @lines << (first_index...last_index)
        ## Set first_index to the next line
        first_index = last_index + 1
      end
      
      last_index = test_index
      ## Searches for the next space or linebreak
      ## Sets text index to nil when reaching the end of the string
      test_index = @text.index /\s|$/, last_index + 1
    end
    ## while test_index breaks when reaching the end of the string
    ## This line adds the last line after it breaks
    @lines << (first_index..last_index)
  end
  
  
  
  def calculate_visible_lines
    text_field_height = @height - @padding*2
    
    512.times do |i|
      text_height = i * @font.height + @font.height
      if text_height >= text_field_height
        @visible_lines = i
        break 
      end
    end
    
  end
  
  
  
  def calculate_last_character_index
    
    if @lines.length <= @visible_lines
      @last_character_index = @lines.last.last
    else
      @last_character_index = @lines[@visible_lines].last
    end
    
  end

  
end
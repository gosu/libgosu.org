=begin
The DeltaTime is used to calculate $delta_time since last frame, for example,
  If gosu is running perfectly at 60 fps then $delta_time = 1
  If gosu is stressed and runs at 30 fps then $delta_time = 2
  $delta_time = 0.5 at 120 fps. etc
This way speed can become independent from the framerate. 

To use it call DeltaTime::calculate on every frame
=end

class DeltaTime
  ## Set default value for $delta_time early, in case it's used on the first frame
  $delta_time = 1
  
  def self.calculate
    ## Set @@prev_frame_time here on first frame only
    @@prev_frame_time = Gosu.milliseconds
    
    ## Override the update function and start calculating on every call.
    def self.calculate
      @@new_time = Gosu.milliseconds
      ## Find the time difference since last second in milliseconds. 
      ## Dividing with 16.66, the standard time between frames.
      $delta_time = (@@new_time - @@prev_frame_time)/16.666666
      ## Set the prev_frame_time to now for next time update is called
      @@prev_frame_time = Gosu.milliseconds
    end
    
  end

  def initialize; raise "DeltaTime, method ‘new’ called for singleton class. Just use the class method Clock::update" end
end
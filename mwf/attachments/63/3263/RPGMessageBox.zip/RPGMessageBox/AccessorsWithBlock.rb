=begin
  attr_accessor :test do
    puts "accessing"
  end
  attr_reader :foo, :bar do
    puts "reading"
  end
  attr_writer :x, :y, :z do
    puts "writing"
  end
=end

class Object
  #### Watch out for this ####
  class << self
    alias _attr_accessor attr_accessor
    alias _attr_reader attr_reader
    alias _attr_writer attr_writer
    
    
    def attr_accessor *args, &block
      return _attr_accessor *args if block.nil?
      
      args.each do |val|
        instance_eval do
          
          self.send :define_method, val do
            eval "@#{val}"
            instance_eval &block
          end
          
          self.send :define_method, "#{val}=" do |value|
            instance_variable_set("@#{val}", value)
            instance_eval &block
          end
        
        end
      end

    end
    
    def attr_reader *args, &block
      return _attr_reader *args if block.nil?
      
      args.each do |val|
        instance_eval do
          
          self.send :define_method, val do
            eval "@#{val}"
            instance_eval &block
          end
        
        end
      end

    end
    
    def attr_writer *args, &block
      return _attr_writer *args if block.nil?
      
      args.each do |val|
        instance_eval do
          
          self.send :define_method, "#{val}=" do |value|
            instance_variable_set("@#{val}", value)
            instance_eval &block
          end
        
        end
      end
        
    end
    
  end  
end
require './MultiLineTextbox'

class RPGMessageBox < MultiLineTextbox
  attr_accessor :speed  
  attr_writer :font, :padding do calculate_lines end
  attr_writer :text do
    @reveal = 0
    calculate_lines
  end
  
  def initialize options = {}
    super options
    @speed = options[:speed] || 0.5
  end
  
  def finish
    return continue if @reveal > @last_character_index
    
    begin
      
     @reveal = @lines[@visible_lines].last
    rescue
      
     @reveal = @lines.last.last
    end
  end
  
  def font= font
    super font
    calculate_lines
  end
  
  def padding= padding
    super padding
    calculate_lines
  end
  
  def update
    @reveal += @speed * $delta_time unless @reveal > @last_character_index
  end
  
  def continue
    if @reveal > @last_character_index
      return if @text.empty?
      
      @text = @text[@last_character_index..@text.length]
      @text.strip!
      @reveal = 0
      
      calculate_lines
    end
  end
  
  def draw
    super
  end
end
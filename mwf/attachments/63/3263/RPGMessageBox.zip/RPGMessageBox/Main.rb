require 'gosu'
require './AccessorsWithBlock'
require './RPGMessageBox'
require './DeltaTime'

class Main < Gosu::Window
  def initialize
    super 800, 600, false
    self.caption = "RPGMessageBox example"
    $window = self
    @message_box_image = Gosu::Image::new(self, 'cheap_looking_message_box.png', false)
    
    @text = "\"Employ your time in improving yourself by other men's writings, so that you shall gain easily what others have labored hard for.\" -Socrates, an excellent open source promoter"
    @message_box = RPGMessageBox::new pos: [220,400], size: [350,100]
    @message_box.font = Gosu::Font::new(self, 'arial', 20)
    @message_box.text = @text
    @message_box.padding = 20
    @message_box.speed = 0.3
  end
  
  def button_down id
    close if id == Gosu::KbEscape
    @message_box.speed = 0.8 if id == Gosu::KbX
    @message_box.continue if id == Gosu::KbX
    @message_box.finish if id == Gosu::KbC
  end
  
  def button_up id
    @message_box.speed = 0.1 if id == Gosu::KbX
  end
  
  def update
    DeltaTime::calculate
    @message_box.update
  end
  
  def draw
    @message_box_image.draw 220,400,0 unless @message_box.text.empty?
    @message_box.draw
  end
end

Main::new.show

include Gosu

# here's my quickly put together "smart prey" class as an example.
# It improved the avg lifetime about 30sec by turning the velocity
# as the hunter approached. Simple.

class Prey < Entity
  attr_accessor :eaten
  
  def initialize(game)
    super(game)
    @accel = P_ACCEL
    @eaten = false
  end
  
  def update(hunters)
    # Find the closest hunter and accelerate away
    closest = find_closest(hunters)
    # take the angle from the hunter to the prey and run along that path
    # in a "smart" offset: prey will move to the side more as hunter
    # approaches. Improved avg lifetime by about 30sec from normal.
    offset = ((400 - distance(@x, @y, closest.x, closest.y)) / 400.00) * 90
    offset = 0 if offset < 0
    accelerate(angle(closest.x, closest.y, @x, @y) + offset)

    move
    !@eaten  # return to verify existence
  end
  
  def draw
    @game.draw_square(@x, @y, 3, 0xff00ff00)
  end
end

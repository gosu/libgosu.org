include Gosu

class Hunter < Entity
  
  attr_reader :frags, :color
  
  def initialize(game, color)
    super(game)    # Entity will define @game
    @accel = H_ACCEL
    @color = color
    @frags = 0
  end
  
  def update(preys)
    # Find the closest prey and accelerate towards it
    closest = find_closest(preys)
    # if closest is too close, eat it
    if distance(closest.x, closest.y, @x, @y) < 5
      closest.eaten = true
      @frags += 1
    end
    # take the angle from the hunter to the prey and run along that path
    accelerate(angle(@x, @y, closest.x, closest.y))
    move
  end
  
  def draw
    @game.draw_square(@x, @y, H_RADIUS, @color)
  end

end


include Gosu

class Entity
  CAP = 0.99
  DAMPEN = 0.9 # set to 1.0 if the walls are trampolines
  
  attr_reader :x, :y
  attr_accessor :vx, :vy
  
  def initialize(game)
    @game = game
    @x, @y = rand(WIDTH), rand(HEIGHT)
    @vx = @vy = 0.0
  end
  
  def move
    # Degrade the velocity so that it will be capped
    @vx = @vx * CAP
    @vy = @vy * CAP
    
    # bounce off the walls
    @vx = (@x < 0 or @x > WIDTH) ? -(@vx) * DAMPEN : @vx
    @vy = (@y < 0 or @y > HEIGHT) ? -(@vy) * DAMPEN : @vy
    
    @x = WIDTH.to_f if @x > WIDTH
    @x = 0.0 if @x < 0
    @y = HEIGHT.to_f if @y > HEIGHT
    @y = 0.0 if @y < 0
    
    # put it together
    @x += @vx
    @y += @vy
  end

  def draw
  end
  
  def find_closest(targets)
    closest = targets.first
    dist = distance(closest.x, closest.y, @x, @y)
    targets.each do |tar|
      new_dist = distance(tar.x, tar.y, @x, @y)
      if new_dist < dist
        closest = tar
        dist = new_dist
      end
    end
    return closest
  end
  
  def accelerate(dir)
    @vx += offset_x(dir, @accel)
    @vy += offset_y(dir, @accel)
  end
  
end


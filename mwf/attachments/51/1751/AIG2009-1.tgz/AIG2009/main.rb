require 'rubygems'
require 'gosu'
require 'entity'
# require 'smart_hunter'  # you will difine this class
require 'hunter'
# require 'smart_prey'    # you will define this class
require 'prey'

include Gosu

WIDTH = 800
HEIGHT = 600
P_ACCEL = 0.0625
H_ACCEL = 0.125  # oh snap. Twice as fast as prey
H_RADIUS = 5

class Simulation < Window
  def initialize
    super(WIDTH, HEIGHT, false)
    self.caption = "Who Let the Dogs Out?"
    @prev_time = milliseconds
    @font = Font.new(self, Gosu.default_font_name, 15)
    @font_color = Color.new(150, 255, 255, 255)
    @timer = 0
    @times = []
    @avg = 0
    @last = 0
    @runs = 0
    resimulate
  end
  
  def update
    # FPS calculation logic taken from AsyncTest.rb that comes with Gosu
    @accum_fps ||= 0
    @cur_sec ||= 0
    @accum_fps += 1
    now = milliseconds
    if @cur_sec != now / 1000
      @cur_sec = now / 1000
      self.caption = "Who Let the Dogs Out? FPS: #{@accum_fps}"
      @accum_fps = 0
    end
    @timer += 1 # one frame gone at 60 fps
    
    (0...4).each do |i|
      (i+1...5).each do |j|
        do_collision(@hunters[i], @hunters[j])
      end
    end
    
    if !@preys.empty?
      @hunters.each {|h| h.update(@preys)}
      @preys.reject! {|p| !p.update(@hunters)}
    else
      resimulate
    end
  end
  
  def draw
    (@hunters + @preys).each {|x| x.draw}
    draw_scoreboard
  end
  
  def button_down(id)
    close if id == Button::KbEscape
    if id == Button::KbD
      @font_color.alpha = (@font_color.alpha == 0) ? 150 : 0
    end
    if id == Button::KbSpace
      @timer = 0
      resimulate
    end
  end
  
  def resimulate
    if @timer != 0
      @times << @timer
      @last = @times.last
      @runs += 1
    end
    @avg = get_avg(@times)
    @timer = 0
    @hunters = [0xffff0000, 0xffffffff, 0xff0000ff, 0xffffff00, 0xff00ffff].map do |c|
      Hunter.new(self, c)
    end
    @preys = Array.new(100) {Prey.new(self)}
  end
  
  # draws a square at x,y with radius r
  def draw_square(x, y, r, color)
    draw_quad(x + r, y + r, color,
              x - r, y + r, color,
              x + r, y - r, color,
              x - r, y - r, color)
  end
  
  def do_collision(h1, h2)
    return if distance(h1.x, h1.y, h2.x, h2.y) > 2 * H_RADIUS
    
    # This math is from http://www.plasmaphysics.org.uk/programs/coll2d_cpp.htm
    # hunters bounce off one another
    x21 = h2.x - h1.x
    y21 = h2.y - h1.y
    
    vx21 = h2.vx - h1.vx
    vy21 = h2.vy - h1.vy
    
    # return if balls are not approaching
    return if vx21*x21 + vy21*y21 >= 0
    
    a = y21 / x21
    dvx2 = -(vx21 + a*vy21)/(1 + a*a)
    advx2 = a*dvx2
    h2.vx += dvx2
    h2.vy += advx2
    h1.vx -= dvx2
    h1.vy -= advx2
  end
  
  def draw_scoreboard
    avg_text = (((@avg.to_f/6.0).round)/10.0).to_s + "sec"
    cur_text = (((@timer.to_f/6.0).round)/10.0).to_s + "sec"
    last_text = (((@last.to_f/6.0).round)/10.0).to_s + "sec"
    runs_text = @runs.to_s
    remaining_text = @preys.size.to_s
    display = "AVG: #{avg_text}, CUR: #{cur_text}, LAST: #{last_text}, RUNS: #{runs_text}, REMAIN: #{remaining_text}"
    @font.draw(display, 10, 10, 3, 1, 1, @font_color)
  end

  def get_avg(array)
    return if array.empty?
    avg = 0
    array.each {|i| avg += i }
    avg /= array.size
    return avg
  end
end

Simulation.new.show


